# -*- coding: utf-8 -*-
"""Modelo independiente (Python puro) a partir de los 3 archivos crudos.
Implementa las reglas de negocio acordadas, sin leer fórmulas del libro."""
import pandas as pd, numpy as np, re, math
from openpyxl import load_workbook

MESES = ['enero','febrero','marzo','abril','mayo','junio','julio','agosto','septiembre','octubre','noviembre','diciembre']


def leer_oc(path):
    """OC abiertas de MP (formato de Facu: encabezado en la fila donde la columna A dice 'ID producto')."""
    ws = load_workbook(path, read_only=True, data_only=True).worksheets[0]
    R = [list(r) for r in ws.iter_rows(values_only=True)]
    out = []
    for i, r in enumerate(R):
        if r and isinstance(r[0], (int, float)) and not isinstance(r[0], bool):
            out.append(dict(fila=i + 1, n=str(r[1] or '').strip(), orden=r[3], prov=r[4], fecha=r[6], pend=max(0.0, float(r[9] or 0))))
    return out

def _fecha(v, defecto):
    import datetime as _dt
    if isinstance(v, _dt.datetime): return v.date()
    if isinstance(v, _dt.date): return v
    try: return _dt.date(int(str(v)[:4]), int(str(v)[5:7]), int(str(v)[8:10]))
    except Exception: return defecto

def entrante_por_mes(skus, entrante, oc, fexp, anio, mes_curso):
    """Reparte el entrante de la base entre las OC más recientes de cada SKU y lo ubica por mes de llegada.
    Vencidas (fecha <= fexp) y entrante sin OC -> mes 2. Devuelve dict sku -> dict(e1..e5, ev, esf, oca, ocp)."""
    by = {}
    for l in oc:
        l = dict(l); l['f'] = _fecha(l['fecha'], fexp); by.setdefault(l['n'], []).append(l)
    res = {}
    for s, ent in zip(skus, entrante):
        lines = sorted(by.get(s, []), key=lambda l: (-l['f'].toordinal(), l['fila']))
        e = [0.0] * 6; ev = 0.0; acum = 0.0; oca = 0.0
        for l in lines:
            a = max(0.0, min(l['pend'], ent - acum)); acum += l['pend']; oca += a
            if l['f'] <= fexp: b = 2; ev += a
            else: b = max(1, min(5, (l['f'].year * 12 + l['f'].month) - (anio * 12 + mes_curso) + 1))
            e[b] += a
        esf = max(0.0, ent - oca); e[2] += esf
        res[s] = dict(e1=e[1], e2=e[2], e3=e[3], e4=e[4], e5=e[5], ev=ev, esf=esf, oca=oca, ocp=sum(l['pend'] for l in lines))
    return res

def meses_sin_llegada(lt_semanas, dias_restantes):
    import math as _m
    if lt_semanas == 0: return 0
    x = max(0, round(lt_semanas * 7) - dias_restantes) / (365 / 12)
    return int(_m.ceil(x - 1e-12))

def model(UP='/mnt/user-data/uploads/', cutoff=8, year=2026, dh_manual=16, overrides=None, base_df=None, hist_df=None, jan=None, oc=None, fexp=None):
    P = dict(sommier=0.15, pocket=600, eps=150, semmes=52/12, uA=0.8, uB=0.95, dps=7, utend=0.3,
             ltd={'Local': 14, 'Brasil': 40, 'China': 90}, ssmin={'Local': 0, 'Brasil': 4, 'China': 6}, ciclo={'Local': 1, 'Brasil': 1, 'China': 4},
             ss={'A': 1, 'B': 2, 'C': 4}, cyc={'A': 2, 'B': 3, 'C': 4}, ss_crit=4,
             forced_origin={**{t: ('China', 'Brasil') for t in ['V406', 'V1551', 'V1554', 'V1553', 'V1558', 'V368']},
                            **{t: ('Brasil', None) for t in ['BASE R POCKET 135X185X18 S/M S/E', 'BASE R POCKET 155X195X18 S/M S/E', 'BASE R POCKET 175X195X18 S/M S/E', 'BASE R POCKET 195X195X18 S/M S/E', 'BASE R POCKET 75X185X18 S/M S/E', 'BASE R POCKET 85X185X18 S/M S/E', 'BASE R POCKET 95X185X18 S/M S/E']}},
             forced_method={t: 'Discontinuado' for t in ['CUERO SILK / STIK #3', 'DENSE HERMES 20#', 'FORM / GIVENCHY 4#']})
    P['forced_origin'].update({t: ('China', 'Local') for t in ['ENGANCHADORES (PAR)', 'MECANISMO EXTENSIBLE ASIENTO (PAR)', 'MOVI RESPALDO (H5)', 'ANCLAJE COCODRILO MACHO', 'ANCLAJE COCODRILO HEMBRA']})
    P['forced_origin'].update({t: ('China', None) for t in ['CONJUNTO MOTOR 516D (PIN / CLIP)', 'LATERAL DERECHO MEC. 516D', 'LATERAL IZQUIERDO MEC. 516D', 'RESORTE 516D', 'TUBO ACERO MEC. 516D L537,8', 'TUBO ACERO MEC. 516D L671,8', 'BRAZO METALICO DERECHO MEC. 8102D', 'BRAZO METALICO IZQUIERDO MEC. 8102D', 'CONJUNTO MOTOR 8102D (MOTOR / TORNILLO)', 'GATILLO DERECHO MEC. 8102M', 'GATILLO LATERAL IZQUIERDO 8102M', 'LATERAL DERECHO MEC. 8102D', 'LATERAL DERECHO MEC. 8102M', 'LATERAL IZQUIERDO MEC. 8102D', 'LATERAL IZQUIERDO MEC. 8102M', 'RESORTE 8102D', 'RESORTE 8102M', 'RESORTE BLOQUEO 8102M', 'TUBO ACERO MEC. 8102M L482,6', 'TUBO ACERO MEC. 8102M L568,4']})
    P['forced_method'].update({t: 'Discontinuado' for t in ['BASE R POCKET 175X195X23 S/M S/E', 'BASE R POCKET 75X185X23 S/M S/E', 'BASE R POCKET 85X185X23 S/M S/E', 'BOUCLE NOVA #15', 'BOUCLE NOVA #16', 'BOUCLE NOVA #18', 'BOUCLE NOVA #2', 'BOUCLE NOVA #21', 'BOUCLE NOVA #3', 'BOUCLE NOVA #4', 'BOUCLE NOVA #5', 'BOUCLE NOVA #8', 'CUERO SILK / STIK #2', 'CUERO SILK / STIK #7', 'CUERO SILK / STIK #8', 'CUERO SILK / STIK #9', 'DENSE HERMES 10#', 'DENSE HERMES 18#', 'DENSE HERMES 21#', 'DENSE HERMES 22#', 'DENSE HERMES 23#', 'DENSE HERMES 5#', 'FORM / GIVENCHY 1#', 'FORM / GIVENCHY 10#', 'FORM / GIVENCHY 11#', 'FORM / GIVENCHY 14#', 'FORM / GIVENCHY 6#', 'FORM / GIVENCHY 8#', 'FORM / GIVENCHY 9#']})
    REEMPLAZO = {}
    P['forced_method'].update({t: 'Agotar stock' for t in ['BRAZO METALICO DERECHO MEC. 8102D', 'BRAZO METALICO IZQUIERDO MEC. 8102D', 'CONJUNTO MOTOR 8102D (MOTOR / TORNILLO)', 'GATILLO DERECHO MEC. 8102M', 'GATILLO LATERAL IZQUIERDO 8102M', 'LATERAL DERECHO MEC. 8102D', 'LATERAL DERECHO MEC. 8102M', 'LATERAL IZQUIERDO MEC. 8102D', 'LATERAL IZQUIERDO MEC. 8102M', 'RESORTE 8102D', 'RESORTE 8102M', 'RESORTE BLOQUEO 8102M', 'TUBO ACERO MEC. 8102M L482,6', 'TUBO ACERO MEC. 8102M L568,4']})

    if overrides: P.update(overrides)
    # ---- base
    b = base_df if base_df is not None else pd.read_excel(UP + 'Base_de_Datos.xlsx')
    rows = []; provs_of = {}; cur = None
    for _, r in b.iterrows():
        nm = r['Nombre en pantalla']
        if isinstance(nm, str) and nm.strip() and isinstance(r['Categoría del producto'], str) and r['Categoría del producto'].strip():
            rows.append(r); cur = nm.strip(); provs_of[cur] = []
        elif isinstance(nm, str) and nm.strip():
            cur = None
        if cur is not None and isinstance(r['Proveedores'], str) and r['Proveedores'].strip():
            provs_of[cur].append(r['Proveedores'].strip())
    d = pd.DataFrame(rows).reset_index(drop=True)
    d['sku'] = d['Nombre en pantalla'].str.strip()
    cat = d['Categoría del producto'].str.strip()
    d['cat'] = np.where(cat == 'Materia Prima', 'Otros', cat.str.replace('Materia Prima / ', '', regex=False))
    d['prov'] = d['Proveedores'].fillna('').astype(str).str.strip()
    d['disp'] = pd.to_numeric(d['Cantidad disponible para uso'], errors='coerce').fillna(0)
    d['ent'] = pd.to_numeric(d['Entrante'], errors='coerce').fillna(0)
    d['costo'] = pd.to_numeric(d['Costo'], errors='coerce').fillna(0)
    exc_cost = {'GRAMPA CLIP CL34 - 22*17': 15, 'GRAMPA CLIP CC32 - 11*14': 12.15}
    forz = {'V406': 1900}
    d['costo'] = [exc_cost.get(s, c) for s, c in zip(d.sku, d.costo)]
    d['forz'] = d.sku.map(forz).fillna(0)
    d['pos'] = d.disp + d.ent
    # línea
    lin = {'Tela Colchon': 'Colchones', 'TNT': 'Colchones', 'Bases': 'Colchones', 'Alambre': 'Colchones', 'Cartones': 'Ambos', 'Mercería': 'Ambos', 'Químicos': 'Ambos'}
    d['lin'] = [('Colchones' if 'NYLON VIRGEN' in s.upper() else 'Living') if c == 'Nylon' else lin.get(c, 'Living') for s, c in zip(d.sku, d.cat)]
    def oprov(n):
        u = n.upper()
        if any(k in u for k in ['FOSHAN', 'GUANGDONG', 'HUZHOU', 'JIANGSU', 'YUYAO', 'ZHE JIANG', 'ZHEIJIANG', 'BEICHI']): return 3
        if any(k in u for k in ['COLORFLEX', 'FITAFLEX']): return 2
        return 1
    NAMES = {1: 'Local', 2: 'Brasil', 3: 'China'}; RANK = {v: k for k, v in NAMES.items()}
    ori, resp = [], []
    for s_ in d.sku:
        rks = sorted({oprov(p) for p in provs_of.get(s_, [])}, reverse=True) or [1]
        if s_ in P['forced_origin']:
            o, rb = P['forced_origin'][s_]; r1 = RANK[o]; r2 = RANK[rb] if rb else 0
        else:
            r1 = rks[0]; lower = [x for x in rks if x < r1]; r2 = lower[0] if lower else 0
        ori.append(NAMES[r1]); resp.append('' if r1 < 3 else (NAMES[r2] if r2 else 'Sin respaldo'))
    d['ori'] = ori; d['resp'] = resp
    # colección
    ren = {'BOUCLE LENNY': 'BOUCLE LENNY', 'BOUCLE NOVA': 'BOUCLE NOVA', 'BOUCLE 5#': 'BOUCLE #5', 'PANA BLONDIE': 'PANA BLONDIE', 'PANA RIFF': 'PANA RIFF',
           'PANA CROSS': 'PANA CROSS', 'PEVECRON LE MANS': 'PEVECRON LE MANS', 'VELVET TWIST': 'VELVET TWIST', 'CUERO SILK / STIK': 'CUERO SILK / STIK',
           'DENSE HERMES': 'DENSE HERMES', 'FORM / GIVENCHY': 'GIVENCHY', 'TC SUNNY': 'SUNNY'}
    def coll(s, c):
        if c != 'Tela Living': return ('', '')
        m = [a for a in ren if s.upper().startswith(a)]
        if m:
            a = max(m, key=len); return (ren[a], s[len(a):].strip())
        w = s.split(' ', 1); return (w[0], w[1].strip() if len(w) > 1 else '')
    cc = [coll(s, c) for s, c in zip(d.sku, d.cat)]
    d['col'] = [x[0] for x in cc]; d['colr'] = [x[1] for x in cc]
    # método
    QP = ['TDI (DI ISIOCANATO DE TOLUENO)', 'VORANOL (POLIOL)', 'VORANOL 3943 (COPO)']
    disc_cols = set((overrides or {}).get('disc_cols', []))
    def met(s, c, cost, col=''):
        if s in P['forced_method']: return P['forced_method'][s]
        if s in QP: return 'Químico principal'
        if cost == 0: return 'Consignado'
        if c == 'Tela Living' and col in disc_cols: return 'Discontinuado'
        if c == 'Bases':
            u = s.upper()
            if 'SOMMIER' in u: return 'Sommier'
            if 'EPS' in u: return 'EPS'
            if 'POCKET' in u and 'X18 ' in (u + ' '): return 'Pocket x18'
            return 'Discontinuado'
        if c in ('Grampas', 'Alambre'): return 'Promedio'
        if c == 'Tela Living': return 'Tela Living'
        return 'Coeficiente'
    d['met'] = [met(s, c, k, cl) for s, c, k, cl in zip(d.sku, d.cat, d.costo, d['col'])]
    def drv(m, l, fz):
        if fz > 0: return 'Mes'
        if m in ('Coeficiente', 'Agotar stock'): return {'Colchones': 'Prod Colchones', 'Living': 'Prod Sillones'}.get(l, 'Prod Total')
        if m == 'Químico principal': return 'Prod Total'
        return {'Promedio': 'Mes', 'Sommier': 'Sommier', 'Pocket x18': 'Pocket x18', 'EPS': 'EPS', 'Tela Living': 'Tela Living'}.get(m, 'Sin proyección')
    d['drv'] = [drv(m, l, f) for m, l, f in zip(d.met, d.lin, d.forz)]
    # ---- consumo
    h = hist_df if hist_df is not None else pd.read_excel(UP + 'Historial_Consumo.xlsx', header=None)
    hdrs = list(h.iloc[1])
    lab = f'{MESES[cutoff-1]} {year}'
    ci = hdrs.index(lab)
    hh = h.iloc[4:].copy(); hh['n'] = hh.iloc[:, 0].astype(str).str.strip()
    cons = {}
    for _, r in hh.iterrows():
        vals = [pd.to_numeric(r.iloc[ci - 3 + j], errors='coerce') for j in range(4)]
        cur = pd.to_numeric(r.iloc[ci + 1], errors='coerce') if ci + 1 < len(hdrs) else np.nan
        cons[r['n']] = ([0 if pd.isna(v) else float(v) for v in vals], 0 if pd.isna(cur) else float(cur))
    C = np.array([cons.get(s, ([0, 0, 0, 0], 0))[0] for s in d.sku])
    d[['c1', 'c2', 'c3', 'c4']] = C
    d['c4t'] = C.sum(1); d['c3t'] = C[:, 1:].sum(1)
    # telas archivadas
    pref = ['ALPHA','BOUCLE','BRUMA','CORANO','CUERO','CUEROTEX','DENSE','FLOW','FLOYD','FORM','JAGUAR','LIO','MILANO','ORION','PANA','PEVECRON','SHOT','SYDNEY','TC','VELVET','CAMBRIDGE','MONT','NAC']
    inbase = set(d.sku)
    m_arch = sum(sum(v[0]) for n, v in cons.items() if n not in inbase and n.split(' ')[0] in pref)
    # ---- rendición
    ws = load_workbook(UP + 'Rendicion.xlsx', read_only=True, data_only=True).worksheets[0]
    R = [list(r) for r in ws.iter_rows(values_only=True)]
    def rowof(lbl):
        for i, r in enumerate(R):
            if isinstance(r[1], str) and r[1].strip().lower() == lbl.lower(): return i
        raise KeyError(lbl)
    def val(i, mes):
        v = R[i][2 + mes] if len(R[i]) > 2 + mes else None
        return float(v) if isinstance(v, (int, float)) else 0.0
    pr = rowof('PRODUCCION REALES'); pc = rowof('PRODUCCION CONSENSUADO'); vc = rowof('VENTAS CONSENSUADO')
    dhm = val(rowof('dias habil del mes'), cutoff + 1)
    if dh_manual is None: dh_manual = val(rowof('Dias habil trascurrido en el mes'), cutoff + 1)
    frac = max(0, dhm - dh_manual) / dhm
    calm = [cutoff - 3 + j for j in range(4)]
    realC = [val(pr + 2, m) for m in calm]; realS = [val(pr + 1, m) for m in calm]
    hm = [cutoff + 1 + j for j in range(4)]
    fac = [frac, 1, 1, 1]
    # v6: hasta diciembre = plan; enero sig. = jan (si se informa) o el mes anterior; después = mes anterior
    J = jan or (0, 0, 0)
    def serie(off, ji):
        out = []
        for i, m in enumerate(hm):
            if m <= 12: out.append(val(off, m))
            elif m == 13 and J[ji] > 0: out.append(J[ji])
            else: out.append(out[-1] if out else 0)
        return out
    planC = serie(pc + 2, 0); planS = serie(pc + 1, 1); ventC = serie(vc + 2, 2)
    m5 = hm[-1] + 1
    if m5 <= 12 and val(pc + 2, m5) > 0:
        n5 = (val(pc + 2, m5), val(pc + 1, m5), val(vc + 2, m5))
    elif m5 == 13 and J[0] > 0:
        n5 = J
    else:
        n5 = (planC[-1], planS[-1], ventC[-1])
    planC5 = planC + [n5[0]]; planS5 = planS + [n5[1]]; ventC5 = ventC + [n5[2]]; fac5 = fac + [1]
    semmes = P['semmes']
    # drivers
    calib = {'Prod Colchones': sum(realC), 'Prod Sillones': sum(realS), 'Prod Total': sum(realC) + sum(realS), 'Mes': 4, 'Sin proyección': 1}
    last = {'Prod Colchones': realC[-1], 'Prod Sillones': realS[-1], 'Prod Total': realC[-1] + realS[-1], 'Mes': 1, 'Sin proyección': 1}
    for k in ['Sommier', 'Pocket x18', 'EPS', 'Tela Living']:
        calib[k] = d.loc[d.drv == k, 'c4t'].sum(); last[k] = 0
    mps = (calib['Tela Living'] + m_arch) / sum(realS)
    def dval(k, j):
        f = fac5[j]
        return {'Prod Colchones': planC5[j] * f, 'Prod Sillones': planS5[j] * f, 'Prod Total': (planC5[j] + planS5[j]) * f, 'Mes': f,
                'Sommier': P['sommier'] * ventC5[j] * f, 'Pocket x18': P['pocket'] * f, 'EPS': P['eps'] * semmes * f,
                'Tela Living': mps * planS5[j] * f, 'Sin proyección': 0}[k]
    import datetime as _dt, calendar as _cal
    fexp = fexp or _dt.date(2026, 10, 2)
    # entrante de la base ubicado por mes con las fechas de las OC abiertas (antes de proyectar: Agotar stock lo usa)
    EM = entrante_por_mes(list(d.sku), list(d.ent), oc or [], fexp, year, cutoff + 1)
    for c in ['e1', 'e2', 'e3', 'e4', 'e5', 'ev', 'esf', 'oca', 'ocp']: d[c] = [EM[x][c] for x in d.sku]
    out = []
    for _, r in d.iterrows():
        k = r.drv; cal = calib[k]; calu = last[k]
        coefb = r.c4t / cal if cal else 0
        coefu = r.c4 / calu if calu else 0
        if r.c4t == 0 or k == 'Sin proyección': rat = None
        elif calu > 0: rat = coefu / coefb if coefb else None
        else: rat = r.c4 / (r.c4t / 4)
        tend = '' if rat is None else ('Creciente' if rat >= 1 + P['utend'] else ('Decreciente' if rat <= 1 - P['utend'] else 'Estable'))
        if r.forz > 0: coef = r.forz
        elif tend == 'Creciente' and r.met in ('Coeficiente', 'Químico principal') and sum(v > 0 for v in (r.c1, r.c2, r.c3, r.c4)) >= 2: coef = max(coefb, coefu)
        else: coef = coefb
        p = [coef * dval(k, j) for j in range(5)]
        if r.met == 'Agotar stock':   # se consume solo hasta agotar disponible + entrante; no se compra
            av = r.disp; ee_ = [r.e1, r.e2, r.e3, r.e4]
            for j in range(5):
                if j < 4: av += ee_[j]
                p[j] = max(0.0, min(p[j], av)); av -= p[j]
        out.append(dict(coefb=coefb, coefu=coefu, tend=tend, coef=coef, p1=p[0], p2=p[1], p3=p[2], p4=p[3], p5=p[4]))
    d = pd.concat([d, pd.DataFrame(out)], axis=1)
    d['pt'] = d[['p1', 'p2', 'p3', 'p4']].sum(1); d['pv'] = d.pt * d.costo
    tot = d.pv.sum()
    pct = [d.loc[d.pv >= v, 'pv'].sum() / tot if v > 0 else None for v in d.pv]
    d['abc'] = ['Sin consumo' if v <= 0 else ('A' if q <= P['uA'] else ('B' if q <= P['uB'] else 'C')) for v, q in zip(d.pv, pct)]
    d['lt'] = [P['ltd'][o] / 7 for o in d.ori]
    d['ltb'] = [P['ltd'][r] / 7 if r in P['ltd'] else 0 for r in d.resp]
    d['cic'] = [P['ciclo'][o] for o in d.ori]
    crit = set(P.get('crit', []))
    d['ss'] = [0 if (a == 'Sin consumo' or m_ == 'Agotar stock') else max(P['ss'][a], P['ssmin'][o], P['ss_crit'] if s in crit else 0) for a, o, s, m_ in zip(d.abc, d.ori, d.sku, d.met)]
    d['obs'] = [0 if (a == 'Sin consumo' or m_ == 'Agotar stock') else l + s for a, l, s, m_ in zip(d.abc, d['lt'], d.ss, d.met)]
    d['mxs'] = [0 if o == 0 else (s + c * semmes + (l if rs in ('Local', 'Brasil') else 0) if c > 1 else o + P['cyc'].get(a, 0)) for o, a, s, c, l, rs in zip(d.obs, d.abc, d.ss, d.cic, d['lt'], d.resp)]
    d['idw'] = [0 if o == 0 else (s + c * semmes / 2 if c > 1 else o) for o, s, c in zip(d.obs, d.ss, d.cic)]
    sem = [f * semmes for f in fac5]
    W = np.array([[r[f'p{j+2}'] / sem[j + 1] if sem[j + 1] else 0 for j in range(4)] for _, r in d.iterrows()])
    rem = _cal.monthrange(fexp.year, fexp.month)[1] - fexp.day
    keys = [(year + (m - 1) // 12) * 100 + (m - 1) % 12 + 1 for m in hm]
    d['cut'] = [next((j + 1 for j, kk in enumerate(keys) if kk >= REEMPLAZO[sx]), 0) if sx in REEMPLAZO else 0 for sx in d.sku]
    d['lm'] = [meses_sin_llegada(x, rem) for x in d['lt']]
    d['lmb'] = [meses_sin_llegada(x, rem) for x in d['ltb']]
    RG = np.zeros((len(d), 4)); CH = np.zeros((len(d), 4)); BK = np.zeros((len(d), 4)); FA = np.zeros((len(d), 4)); EN = np.zeros((len(d), 4))
    for i, r in d.iterrows():
        pp = [r.p1, r.p2, r.p3, r.p4, r.p5]; ee = [r.e1, r.e2, r.e3, r.e4]; stock = r.disp; arrived = False
        for k in range(4):
            start = stock if (k + 1) != r.cut else 0.0; raw = start + ee[k] - pp[k]; arrived_before = arrived
            if r.cic > 1:   # compra por ciclo (China)
                SSk = r.ss * W[i, k]; ch = 0.0
                if (k + 1) >= r.lm + 1 and not arrived and raw < SSk:
                    months = [pp[j] if j < 4 else pp[4] for j in range(k, k + int(r.cic))]
                    ecy = sum(ee[j] for j in range(k, 4) if j <= k + r.cic - 1)
                    ch = max(0.0, sum(months) + r.ss * W[i, 3] - start - ecy); arrived = arrived or ch > 0
                gap = max(0.0, SSk - raw - ch)
                if r.resp in ('Local', 'Brasil'):
                    if (k + 1) > r.lmb and gap > 0:   # lote local que cubre hasta la próxima llegada de China
                        nxt = next((j + 1 for j in range(k + 1, 4) if ee[j] > 0), 5)
                        A_ = min(nxt, r.lm + 1 if (not arrived_before and r.lm + 1 > k + 1) else 5)
                        cov = sum(pp[j] - ee[j] for j in range(k, 4) if j + 1 < A_)
                        BK[i, k] = max(0.0, cov + r.ss * W[i, max(1, A_ - 1) - 1] - start - ch)
                    else: BK[i, k] = 0.0
                else: FA[i, k] = gap
                CH[i, k] = ch; stock = raw + ch + BK[i, k]
            else:           # compra mensual: cada mes cierra en su objetivo, desde el primer mes en que puede llegar
                RG[i, k] = 0.0 if (k + 1) <= r.lm else max(0.0, r.obs * W[i, k] - raw); stock = raw + RG[i, k]
            EN[i, k] = stock
    Rm = RG + CH + BK
    d['mag'] = [(next((k + 1 for k in range(4) if EN[i_, k] <= 0.001), 0) if m_ == 'Agotar stock' else 0) for i_, m_ in enumerate(d.met)]
    d['obso'] = [0.0 if c_ == 0 else max(0.0, r_.disp if c_ == 1 else EN[i_, c_ - 2]) for i_, (c_, r_) in enumerate(zip(d.cut, d.itertuples()))]
    for j in range(4):
        d[f'rg{j+1}'] = RG[:, j]; d[f'ch{j+1}'] = CH[:, j]; d[f'bk{j+1}'] = BK[:, j]; d[f'fal{j+1}'] = FA[:, j]; d[f'en{j+1}'] = EN[:, j]
    d[['r1', 'r2', 'r3', 'r4']] = Rm; d['rt'] = Rm.sum(1)
    for j in range(4): d[f'rd{j+1}'] = Rm[:, j] * d.costo
    d['rdt'] = d.rt * d.costo
    O = np.zeros((len(d), 5))
    for i in range(len(d)):
        for j in range(4):
            e = j - d.lm[i]; O[i, 0 if e < 0 else e + 1] += RG[i, j] + CH[i, j]
            e = j - d.lmb[i]; O[i, 0 if e < 0 else e + 1] += BK[i, j]
    for j in range(5): d[f'o{j}u'] = O[:, j]; d[f'o{j}'] = O[:, j] * d.costo
    lmu = [lb if (c > 1 and rs in ('Local', 'Brasil')) else lm_ for lb, lm_, c, rs in zip(d.lmb, d.lm, d.cic, d.resp)]
    d['o0u'] = [max([0.0] + [r.ss * W[i, k] - EN[i, k] for k in range(4) if k < lmu[i]]) for i, r in d.iterrows()]
    d['o0'] = d.o0u * d.costo
    q27, em27 = [], []
    for i, r in d.iterrows():
        n = 0
        if r.cic > 1 and CH[i].sum() == 0 and r.p5 > 0 and r.met != 'Agotar stock':
            n = max(1, int(math.floor((EN[i, 3] - r.ss * W[i, 3]) / r.p5)) + 1)
        em = 4 + n - r.lm if n else 0
        em = em if 1 <= em <= 4 else 0
        em27.append(em); q27.append(max(0.0, r.cic * r.p5 + r.ss * W[i, 3] - (EN[i, 3] - (n - 1) * r.p5)) if em else 0.0)
    d['q27'] = q27; d['em27'] = em27
    d['qm'] = [next((k + 1 for k in range(4) if EN[i, k] < 0), 0) for i in range(len(d))]
    d['wref'] = W[:, 0]
    d['obu'] = d.obs * d.wref; d['mxu'] = d.mxs * d.wref; d['ssu'] = d.ss * d.wref
    cons_ = d.met == 'Consignado'
    d['va'] = np.where(cons_, 0, d.disp * d.costo); d['vi'] = np.where(cons_, 0, d.idw * d.wref * d.costo)
    def est(r):
        if r.met == 'Consignado': return 'Consignado'
        if r.met == 'Agotar stock': return 'Agotar stock'
        if r.met == 'Discontinuado': return 'Discontinuado' if r.disp > 0 else 'Sin stock ni consumo'
        if r.wref == 0: return 'Sin consumo proyectado' if r.disp > 0 else 'Sin stock ni consumo'
        cob = r.disp / r.wref
        if cob < r.ss: return 'Debajo del stock de seguridad'
        if cob < r.obs: return 'Debajo del objetivo'
        if cob <= r.mxs: return 'En rango'
        return 'Exceso'
    d['est'] = d.apply(est, axis=1)
    d['sm'] = np.where((d.c3t == 0) & (d.disp > 0) & ~cons_, d.disp * d.costo, 0)
    d['ex'] = np.where((d.wref > 0) & ~cons_ & (d.met != 'Agotar stock'), np.maximum(0, d.disp - d.mxu) * d.costo, 0)
    d['disc'] = np.where((d.met == 'Discontinuado') & (d.sm == 0), d.va, 0)
    d['cap'] = np.where(d.sm > 0, d.sm, np.where(d.disc > 0, d.disc, d.ex))
    d['dias'] = np.where(d.wref > 0, d.disp / (d.wref / P['dps']).replace(0, np.nan), np.nan)
    meta = dict(frac=frac, mps=mps, m_arch=m_arch, calib=calib, planC5=planC5, planS5=planS5, ventC5=ventC5)
    return d, meta
