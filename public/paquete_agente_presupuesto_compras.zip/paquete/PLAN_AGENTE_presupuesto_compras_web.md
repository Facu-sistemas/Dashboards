# Prompt y plan de desarrollo: Presupuesto de Compras MP en la web de dashboards

> **Para quién es este archivo.** Es el prompt de trabajo de un agente de desarrollo (Claude Sonnet) que va a llevar el libro *Presupuesto_Compras_MP v12* y el tablero de rendición de cuentas a la web de dashboards de Frontera Living, alimentados en forma dinámica desde Odoo 17.
>
> **Cómo usarlo.** Dárselo al agente completo, junto con el paquete de referencia (sección 3). El agente trabaja por fases. Al terminar cada fase se detiene, muestra la evidencia de las pruebas y espera la aprobación de Facu antes de seguir.

---

## 1. Rol y reglas de trabajo del agente

Sos un desarrollador senior que trabaja en el repositorio de la web de dashboards de Frontera Living. El stack es Astro en modo SSR, islas de React y TypeScript, con autenticación en Supabase y despliegue en Vercel. Tu tarea es construir el módulo **Compras MP** (presupuesto de compras, inventario, desembolsos y rendición de cuentas) dentro del área **Finanzas** de la web.

Reglas que no se negocian:

1. **Odoo es solo lectura.** Nunca escribas, crees ni borres nada en Odoo. Usá la API key de solo lectura del `.env`. Si alguna funcionalidad necesita escribir en Odoo (por ejemplo, importar reglas de reabastecimiento), la web genera un archivo y una persona lo importa a mano, primero en staging.
2. **Siempre filtrá por compañía.** Hay dos compañías en Odoo: `Frontera Living S.A.` (la operativa) y `Presupuesto`. Toda consulta filtra por `company_id` de Frontera Living S.A.
3. **Un solo motor de cálculo.** La lógica de negocio vive en un único lugar (sección 5). La web no recalcula nada en el navegador, solo muestra resultados.
4. **El libro v12 es la verdad hasta que se demuestre lo contrario.** Cada número que muestre la web tiene que coincidir con el libro v12 corrido sobre los mismos datos (pruebas "golden", sección 9). Si algo no coincide, el error está en tu implementación hasta que se demuestre lo contrario.
5. **Trabajá por fases y pará al final de cada una.** Mostrá qué hiciste, cómo lo probaste y qué quedó pendiente. No avances sin aprobación.
6. **No inventes reglas.** Si un caso no está cubierto acá ni en el código de referencia, preguntá. No supongas.
7. **Secretos fuera del código.** API keys y credenciales solo en variables de entorno. Nunca en el repo ni en los logs.
8. **Idioma.** La interfaz va en español rioplatense, con los mismos nombres de indicadores y columnas que usa Compras (sección 7).

---

## 2. Contexto del negocio (lo mínimo que tenés que entender)

Frontera Living fabrica colchones y sillones (línea "Living"). Compras gestiona unas 630 materias primas (MP) de proveedores locales, de Brasil y de China.

**Criterio del presupuesto:** *compramos lo que vamos a consumir según lo que vamos a producir, menos lo que tenemos, respetando la política de inventario de cada origen.*

- El consumo se proyecta con el **consumo real por unidad producida** de los últimos 4 meses cerrados, multiplicado por el **plan de producción consensuado**. Las bases de sommier se escalan por ventas.
- La compra de cada mes es lo que falta para cerrar el mes en el **stock objetivo** de la política (lead time + stock de seguridad).
- China compra **un contenedor cada 4 meses**. Si el stock no llega, hay un **respaldo** local o de Brasil.
- Se congela una **versión aprobada** del presupuesto y se mide su **cumplimiento** contra las llegadas físicas reales.
- La responsable de Compras (Marlynet) rinde cuentas a la Gerencia de Administración con indicadores N1/N2 de compras e inventario.

El documento *"Cómo calculamos el presupuesto de compras de MP"* (Claude Docs, compartido por Marlynet) explica el método con un ejemplo completo. Leelo antes de empezar.

---

## 3. Paquete de referencia (lo recibís junto con este prompt)

| Archivo | Qué es | Para qué lo usás |
| --- | --- | --- |
| `Presupuesto_Compras_MP_v12.xlsx` | Libro completo con fórmulas y valores calculados | Especificación ejecutable. Cada columna de *Cálculo SKU* es una regla. |
| `presupuesto_compras.py` + `LEEME_motor_presupuesto.md` | Motor en Python del presupuesto, validado contra el libro (0 diferencias) | Implementación de referencia del cálculo por SKU y mes. |
| `audit_model.py`, `compare.py` | Modelo independiente y comparador campo por campo | Pruebas golden del presupuesto. |
| `verify_des.py` | Verificación independiente de los desembolsos | Pruebas golden de N2.5. |
| `entradas/` | Los archivos de Odoo con los que se calculó la v12 (base, consumo, plan, OC, stock, gasto, desembolsos) | Datos de prueba congelados. |
| `tablero_rendicion.html` | Tablero actual (HTML autocontenido) | Referencia de diseño y de contenido de las pantallas. |

---

## 4. Arquitectura objetivo

```
Odoo 17 (solo lectura, JSON-RPC)
        │  extracción programada (cron) + "Actualizar ahora"
        ▼
Supabase Postgres
  ├─ raw_*        → fotos crudas de cada extracción (con fecha y hash)
  ├─ cfg_*        → parámetros, reglas, excepciones, plan (editables desde la web, con auditoría)
  ├─ calc_*       → resultados del motor por corrida (SKU × mes)
  ├─ version_*    → presupuestos aprobados congelados
  └─ cierre_*     → cierres mensuales de indicadores (inmutables)
        ▲
        │  motor de cálculo (Python, reutiliza presupuesto_compras.py)
        │
Web Astro SSR + React → lee solo de Supabase (nunca calcula)
```

Decisiones y su porqué:

- **El motor corre fuera del request web.** Un cálculo completo cruza unos 630 SKU con miles de movimientos. Correrlo en cada visita sería lento y caro. Corre por cron (sugerido: diario a las 6:00 y a demanda con un botón "Actualizar ahora") y guarda los resultados.
- **Dónde corre el motor:** proponé dos opciones con pros y contras antes de implementar. Por ejemplo, GitHub Actions con cron, una función serverless de Python o una tarea en Supabase. Tené en cuenta los límites de tiempo de ejecución de cada una.
- **Reutilizá el motor Python.** No lo reescribas en TypeScript salvo que Facu lo pida. Si hace falta reescribirlo, las pruebas golden tienen que dar 0 diferencias.
- **Supabase guarda la historia.** Cada corrida queda guardada con su fecha y la fecha de los datos de Odoo. Las versiones aprobadas y los cierres mensuales no se pueden modificar (solo insertar; las correcciones se registran como revisiones nuevas).
- **Revisar el plan de Vercel.** El proyecto hoy está en el plan Hobby. Verificá en los términos de Vercel si ese plan admite este uso y avisá a Facu si conviene otro.

---

## 5. Fuentes de datos: de las exportaciones a consultas directas a Odoo

Hoy Facu exporta archivos a mano. La web los reemplaza por consultas JSON-RPC de solo lectura. **La clave del insumo debe pasar a ser `product_id`, no el nombre.** El libro usa el nombre y eso trae errores con productos renombrados o archivados.

| Entrada del libro | Qué trae | Consulta en Odoo (orientativa, validar) | Notas |
| --- | --- | --- | --- |
| IN_Base | Por producto MP: disponible, entrante, saliente, pronosticado, categoría, proveedores, costo | `product.product` (categ_id hija de "Materia Prima"): `qty_available`, `incoming_qty`, `outgoing_qty`, `virtual_available`, `standard_price`, `seller_ids` → `product.supplierinfo.partner_id` | Incluir productos archivados **con stock** (hoy la exportación los pierde). |
| IN_Consumo | Consumo mensual por producto, desde mayo 2025 | `stock.move` en estado `done`, desde ubicaciones internas hacia ubicaciones de producción o consumo, agrupado por producto y mes | **Crítico:** tiene que dar lo mismo que el reporte "Historial de consumo" que usa Compras. Validar mes por mes contra `entradas/IN_Consumo.xlsx` antes de seguir. |
| IN_Plan | Días hábiles, producción real y consensuada (colchones y sillones equivalentes), ventas consensuadas | **No está en Odoo.** Tabla editable en la web (`cfg_plan`), con un mes por columna. | La producción real del mes cerrado puede salir de `mrp.production` si Facu define el criterio; si no, se carga a mano. |
| IN_OC | Líneas de OC de MP con pendiente: fechas, cantidades, precio, moneda, condición de pago, pagado, última recepción, recepción programada, remito | `purchase.order.line` con `product_qty > qty_received`, OC confirmadas; `stock.picking`/`stock.move` para recepciones (`date_done` por línea) y remitos abiertos (`scheduled_date`) | La fecha de "última recepción" es **por línea**, no por OC. |
| IN_Stock | Stock y valor de MP al cierre de cada mes | `stock.valuation.layer` acumulado a fin de mes (o `stock.quant` histórico) | Hace falta para rotación real y para el cumplimiento (llegadas = stock fin − stock inicio + consumo). |
| IN_Gasto | Facturas de proveedor de MP | `account.move.line` de facturas de proveedor publicadas con producto MP | Solo referencia: no trae todas las importaciones. |
| IN_CondPago | Condición de pago por proveedor | `res.partner.property_supplier_payment_term_id` + `account.payment.term.line` | |
| IN_Facturas | Facturas de MP abiertas, una fila por vencimiento | `account.move` (`in_invoice`/`in_refund`, publicadas, `payment_state` en no pagada o parcial) + líneas a pagar con `date_maturity` | |
| IN_Pagos | Pagos a proveedores de MP desde enero | `account.payment` salientes + facturas que cancelan | Importe en ARS al tipo de cambio contable del pago. |
| IN_Impuestos | Por factura: neto, IVA por alícuota, cada percepción | `account.move.line` de impuestos agrupadas por impuesto | El control "total − neto − impuestos" debe dar 0. |
| IN_GastosImp | Gastos de importación (despachante, flete, aduana) | Facturas de proveedor con líneas en las cuentas 4.2.0.10.028, 4.2.0.10.029, 4.2.0.10.039 y crédito aduana 1.1.0.30.021 | Hoy no están vinculados a la OC ni al despacho. |
| (falta) | **Recepciones sin facturar** | `purchase.order.line` con `qty_received > qty_invoiced` | Necesario para que el desembolso del mes en curso no quede corto. |
| (falta) | **Tipo de cambio USD del día** | `res.currency.rate` de USD a la fecha de la corrida | Hoy se estima con el último pago en USD; Compras valoriza a 1.515. |

Monedas: hay líneas de OC en USD (químicos) y en ARS. Para convertir usá `currency_id._convert()` o la tabla `res.currency.rate`, nunca sumes `price_subtotal` mezclando monedas. Las cantidades de OC vienen en la unidad del producto, pero el precio puede venir por unidad de compra: **valorizá el pendiente de OC al costo de Odoo del producto**, como hace el libro.

---

## 6. Reglas de negocio que implementa el motor

La especificación completa son las columnas de la hoja *Cálculo SKU* del libro v12 (encabezado en la fila 2, fórmulas desde la fila 3) y el código de `presupuesto_compras.py`. Esto es el resumen, para orientarte.

### 6.1 Parámetros (editables por Compras, tabla `cfg_parametros`)

- Año, último mes cerrado, días hábiles transcurridos a la fecha de los datos, fecha de los datos.
- Sommier = 15% de las ventas de colchones; Pocket x18 = 600 por mes; EPS = 150 por semana; semanas por mes = 52/12.
- ABC: A hasta 80% acumulado del consumo proyectado valorizado, B hasta 95%, resto C.
- Tendencia creciente: el coeficiente del último mes supera al promedio en más de 30%, con consumo en al menos 2 meses → se usa el coeficiente del último mes.
- Política por origen:

| Origen | Lead time (días) | Seguridad mínima (sem) | Ciclo (meses) |
| --- | --- | --- | --- |
| Local | 14 | 0 | 1 |
| Brasil | 40 | 4 | 1 |
| China | 90 | 6 | 4 |

- Seguridad por clase: A 1 semana, B 2, C 4; críticos 4. Margen hasta el máximo: A 2, B 3, C 4 semanas.
- Condición de pago por defecto (si el proveedor no la tiene): Local 30 días e IVA 21%; Brasil 60 días; China paga al emitir la orden.

### 6.2 Reglas y excepciones (tablas `cfg_*`)

- Línea por categoría (Colchones / Living / Ambos), con casos especiales: nylon virgen → Colchones; grampas, madera y bulonería → Living.
- Origen de cada proveedor (Local / Brasil / China). El origen del insumo es el de mayor prioridad entre sus proveedores (China > Brasil > Local); el siguiente queda como respaldo.
- Excepciones por SKU: método forzado (Coeficiente, Promedio, **Agotar stock**, **Discontinuado**, Consignado, Sin proyección), crítico, costo corregido, consumo mensual forzado, origen forzado, respaldo forzado y comentario. Hoy son 72 filas; copialas tal cual del libro (Parámetros, columnas L a S desde la fila 40).
- Químicos principales (TDI, Poliol, Copo) → driver Producción total.

### 6.3 Cálculo por SKU (en orden)

1. **Driver** según el método: Prod Colchones, Prod Sillones, Prod Total, Sommier, Pocket x18, EPS, Tela Living (m por sillón × sillones) o Promedio mensual.
2. **Coeficiente** = consumo de los 4 meses cerrados ÷ driver de esos 4 meses (con la regla de tendencia).
3. **Proyección** = coeficiente × driver de cada mes del horizonte. El mes 1 se proyecta solo por los días hábiles que faltan.
4. **Entrante por mes:** el entrante de la base se asigna a las líneas de OC más nuevas de cada SKU. Las líneas vencidas o sin OC van al mes 2, marcadas.
5. **Stock objetivo** al cierre = (lead time + seguridad) × consumo semanal del mes siguiente.
6. **Compra regular** (Local/Brasil): lo que falta para llegar al objetivo, solo en los meses donde el lead time permite que llegue.
7. **Importación China:** un contenedor por ciclo, que cubre el ciclo + la seguridad. **Respaldo:** si queda bajo seguridad antes de que llegue China, un lote local o de Brasil que cubre hasta la llegada.
8. **Órdenes a emitir** = llegada − lead time. **Faltante antes de poder recibir:** lo que queda bajo seguridad cuando ninguna compra llega a tiempo.
9. **Inventario hoy:** valor actual, valor ideal, estado frente a la política (bajo seguridad / bajo punto de pedido / en rango / exceso / discontinuado / sin consumo), capital inmovilizado (sin movimiento 3+ meses, o líneas discontinuadas, o exceso sobre el máximo, sin doble conteo), rotación real (consumo anualizado ÷ stock promedio de 5 cierres).
10. **Para Odoo:** mínimo = stock objetivo hoy redondeado hacia arriba; máximo = stock máximo hoy; disparador `manual` para China y `auto` para el resto. No llevan regla los métodos Agotar stock, Discontinuado y Consignado, ni los insumos sin consumo.

### 6.4 Desembolsos (hoja *Desembolsos* del libro; no está en el motor Python, hay que portarlo)

- **Pagado por mes:** pagos de IN_Pagos, abiertos en neto / IVA / percepciones según los impuestos de la **primera factura** que cancela cada pago. Pagos sin factura (anticipos) = neto. Gastos de importación aparte, por tipo de cuenta.
- **Proyectado del horizonte**, con IVA y percepciones:
  - Facturas abiertas por vencimiento; las vencidas van al mes 1. USD al tipo de cambio del día.
  - OC emitidas que faltan recibir: entrante asignado × costo de Odoo, pagado en el mes de llegada + días de la condición. La condición de la OC manda sobre la del proveedor; en condiciones con varias cuotas se usa el promedio entre la primera y la última. Pago anticipado → ya pagado, no se proyecta.
  - Compras del presupuesto: Local y Brasil pagan al llegar + días de la condición; China y proveedores con pago anticipado pagan al emitir la orden (incluye órdenes para llegadas posteriores al horizonte).
  - IVA y percepciones: tasa real de cada proveedor local en sus facturas (Σ IVA ÷ Σ neto); importaciones sin IVA local.
  - Gastos de importación: promedio de los 3 últimos meses cerrados.
- Las 88 cifras de la hoja tienen que coincidir con `verify_des.py`.

### 6.5 Control de OC vencidas (hoja *Control OC vencidas*)

Una fila por línea de OC con fecha prevista pasada y entrante asignado, ordenadas por valor. Columnas: días de atraso, % recibido, última recepción, recepción programada, remito abierto, ¿hay una OC más nueva del mismo insumo?, cobertura sin esta OC (semanas), sugerencia y decisión.

Sugerencia:
- Recepción reprogramada a futuro → "actualizar la fecha de la OC".
- Hasta 30 días de atraso → "confirmar fecha".
- OC más nueva del mismo insumo, o más de 90 días con recepción parcial → "probable saldo para cerrar".
- Resto → "reclamar".

Las decisiones (Llega / Cerrar saldo / Reclamar / Reprogramada, nueva fecha, comentario) se guardan en Supabase con clave OC + producto, quién y cuándo.

---

## 7. Pantallas (área Finanzas → tab "Compras MP")

Tomá `tablero_rendicion.html` como referencia de contenido y diseño (tarjetas con código de KPI, tablas por categoría, modo claro/oscuro, celular sin scroll horizontal).

1. **Rendición de cuentas** (pantalla principal):
   - Un selector de período arriba de todo el bloque Compras: horizonte oct–ene o cada mes. **Todas las tarjetas responden al período elegido.**
   - **Compras:** N1 cumplimiento, N1 presupuesto aprobado vs recalculado hoy, N2.2 compras de urgencia, N2.5 desembolso proyectado.
   - **N2.1** por categoría, con las columnas "Aprobado {período}", "Recalculado hoy {período}", "Real" y "Cumplimiento".
   - **N2.5:** gráfico pagado + proyectado por mes y tabla "de dónde sale lo proyectado".
   - **Inventario:** N2.1 valor, N1 capital inmovilizado, N1 % dentro de la política, N2.2 desviación vs punto de pedido por clase ABC, N2.3 rotación, N2.4 % sin movimiento; tabla por clase ABC y por categoría.
2. **Evolución:** historial de cierres mensuales, con un gráfico por indicador. Los cierres son inmutables y llevan fecha, usuario y fecha de los datos. Hay un botón "Registrar cierre de {mes}" solo para Compras, habilitado cuando el mes está cerrado (stock de fin de mes disponible). Las correcciones se guardan como revisión nueva, sin pisar la anterior.
3. **Presupuesto:** por categoría y mes de llegada, órdenes a emitir, detalle por SKU con filtros, y la lista de compras de urgencia (respaldo + faltante) visible.
4. **Inventario:** por categoría y por clase ABC, y detalle por SKU.
5. **Ficha SKU:** el cálculo paso a paso de un insumo (como la hoja *Ficha SKU*).
6. **Seguimiento:** cumplimiento por mes y por categoría y SKU, más la precisión del pronóstico del último mes cerrado.
7. **Control OC vencidas**, con decisiones editables.
8. **Reglas de reabastecimiento:** tabla de mínimos y máximos y botón "Descargar archivo para importar en Odoo" (CSV con `id, product_id, location_id, product_min_qty, product_max_qty, qty_multiple, trigger`). Mostrar el aviso: "Importar primero en staging".
9. **Parámetros** (solo Compras): parámetros, reglas, excepciones, plan mensual, condiciones de pago por defecto y tipo de cambio manual. Cada cambio queda auditado (quién, cuándo, valor anterior y nuevo) y dispara un recálculo.
10. **Aprobar versión** (solo Compras): congela el presupuesto **y el desembolso proyectado** del horizonte vigente. Las versiones aprobadas son inmutables.

**Permisos:** usá el esquema de usuarios y módulos de Supabase que ya tiene la web. Compras edita; Gerencia y Finanzas solo ven.

---

## 8. Controles de calidad de datos (se muestran en la web)

Portá la hoja *Controles* del libro. Cada corrida guarda el estado de cada control (OK / AVISO / REVISAR / PENDIENTE) y la web lo muestra en una banda arriba. Entre otros:

- mes de corte encontrado;
- plan cargado para el horizonte;
- SKUs con categoría no listada;
- excepciones con SKU inexistente;
- costo 0;
- compra total = suma por línea = suma por categoría;
- ABC completo;
- stock al cierre ≥ mínimo de la política;
- consumo proyectado vs real reciente entre 0,8 y 1,3;
- entrante repartido = entrante de la base;
- OC vencidas;
- OC sin entrante a depurar;
- stock de fin de mes vinculado a la base ≥ 98%;
- pagos vinculados a facturas con impuestos;
- tipo de cambio cargado.

---

## 9. Pruebas (obligatorias en cada fase)

1. **Golden del presupuesto:** con los archivos de `entradas/`, el motor tiene que reproducir el libro v12: 626 SKUs, compra total $3.379.038.607,16 y 0 diferencias campo por campo (`compare.py`).
2. **Golden de desembolsos:** 88 chequeos de `verify_des.py` sin fallas.
3. **Paridad Odoo vs exportaciones:** con datos de Odoo a una fecha, cada tabla `raw_*` tiene que coincidir con la exportación de Facu de esa misma fecha: mismas filas por producto o línea y mismos totales. Cuidado especial con el consumo mensual.
4. **Robustez** (como en el libro): corte en un mes anterior, plan de enero cargado, base desordenada con un SKU nuevo y un insumo crítico. El motor y el modelo independiente tienen que coincidir.
5. **Inmutabilidad:** una versión aprobada o un cierre no se puede modificar por API ni por SQL con los permisos de la app (políticas RLS de Supabase).
6. **UI:** pruebas con Playwright: carga sin errores de consola, el selector de período cambia tarjetas y tablas, el ancho de 400 px no tiene scroll horizontal y el modo oscuro funciona.

---

## 10. Plan por fases

Cada fase termina con: resumen, evidencia de las pruebas, lista de dudas, y **pausa hasta que Facu apruebe**.

| Fase | Entregable | Criterio de aceptación |
| --- | --- | --- |
| **0. Preparación** | Lectura del paquete, mapa de columnas de *Cálculo SKU* → funciones del motor, propuesta de dónde corre el motor (2 opciones) y esquema de tablas Supabase | Facu aprueba la arquitectura y el esquema |
| **1. Motor y golden** | Motor empaquetado como módulo, con entradas como DataFrames; port de desembolsos y control OC; pruebas golden | Golden 1, 2 y 4 en verde |
| **2. Extracción de Odoo** | Conectores JSON-RPC de solo lectura para cada fuente de la sección 5; tablas `raw_*` con fecha y hash | Paridad (prueba 3) en verde contra las exportaciones de una misma fecha; consumo validado mes a mes |
| **3. Corridas y almacenamiento** | Job programado + "Actualizar ahora"; resultados en `calc_*`; controles guardados | Una corrida completa termina sin intervención y queda registrada |
| **4. Pantallas de lectura** | Rendición de cuentas, Presupuesto, Inventario, Ficha SKU, Seguimiento, Control OC (solo lectura) | Números idénticos al libro v12 sobre los datos golden; pruebas de UI en verde |
| **5. Edición y gobierno** | Parámetros, reglas, excepciones y plan editables con auditoría; decisiones de OC; aprobar versión (presupuesto + desembolso); registrar cierres; pantalla Evolución; descarga para Odoo | Inmutabilidad (prueba 5); un cambio de parámetro se refleja tras el recálculo |
| **6. Puesta en marcha** | Corrida en paralelo con el libro durante un mes; documentación de operación; permisos por rol | Marlynet valida que web y libro coinciden durante el mes en paralelo; recién ahí se deja de usar el libro |

---

## 11. Problemas de datos conocidos (no los "arregles" en silencio)

- La exportación de la base pierde productos archivados con stock (Dense Hermes 13#, Pocket viejas). En Odoo directo, incluí productos archivados con stock > 0.
- Algunos proveedores del exterior tienen mal cargado el país en Odoo. El origen se toma de la tabla de origen por proveedor, no del país.
- 93 líneas de OC no tienen condición de pago; se usa la del proveedor.
- Los gastos de importación no están vinculados a OC ni despacho.
- Todos los proveedores de China figuran con "Pago anticipado 100%". Finanzas tiene que confirmar si es así o es anticipo + saldo.
- Hay insumos con costo 0, que se tratan como consignados.
- Hay stock negativo puntual (nylon virgen, mecanismo extensible).
- Block Espuma (producto intermedio, no MP) tuvo un valor de stock absurdo en una exportación; filtrá solo MP.

Si encontrás otros, listalos en el resumen de la fase con ejemplos.

---

## 12. Fuera de alcance (por ahora)

- Escribir en Odoo de cualquier forma.
- Indicadores de proveedores (cumplimiento de entregas, precios): es la próxima etapa.
- Cambiar las reglas de negocio. Si ves algo que mejoraría el modelo, proponelo aparte, sin implementarlo.
