"""Verificación independiente de la hoja Desembolsos (Python, sin fórmulas del libro)."""
import sys, json, datetime as dt, collections, re
import openpyxl
from openpyxl.utils import column_index_from_string as ci
SP = '/tmp/claude-0/-home-claude/90e6f4dc-5e9c-57cc-918f-b70f24dbefb4/scratchpad/'
BOOK = sys.argv[1]
DES = SP + 'in5/desembolsos_mp.xlsx'; OCF = SP + 'in5/oc_pendientes_mp.xlsx'
FEXP = dt.date(2026, 10, 6); YEAR = 2026; CUR = 10
DEF = {'Local': (30, 0, 0.21, 0.0), 'Brasil': (60, 0, 0.0, 0.0), 'China': (0, 1, 0.0, 0.0)}
wb = openpyxl.load_workbook(BOOK, read_only=True, data_only=True)
dw = openpyxl.load_workbook(DES, read_only=True, data_only=True)
def rows(name):
    r = list(dw[name].iter_rows(values_only=True)); return r[5:]
N = lambda v: v if isinstance(v, (int, float)) else 0
def d(s):
    if isinstance(s, dt.datetime): return s.date()
    try: return dt.date(int(s[:4]), int(s[5:7]), int(s[8:10]))
    except Exception: return None
# proveedores: origen (Parámetros AC:AD)
pm = wb['Parámetros']; ORIG = {}
for r in pm.iter_rows(min_row=5, min_col=29, max_col=30, values_only=True):
    if r[0]: ORIG[str(r[0]).strip()] = r[1]
cond = {}
for r in rows('1a Cond. pago proveedor'):
    if r[0] and r[2] is not None: cond[str(r[0]).strip()] = (str(r[2] or ''), str(r[4] or ''))
def resdays(res):
    m = re.search(r' a (\d+) d', res or ''); return int(m.group(1)) if m else None
# impuestos
imp = {}; rate = collections.defaultdict(lambda: [0, 0, 0])
for r in rows('5 Impuestos por factura'):
    if not r[2] or r[2] == 'Número': continue
    neto, iva, perc, tot = N(r[7]), N(r[8]) + N(r[9]), sum(N(x) for x in r[10:24]), N(r[24])
    imp[str(r[2]).strip()] = (neto, iva, perc, tot)
    if r[5] == 'ARS': o = rate[str(r[0]).strip()]; o[0] += neto; o[1] += iva; o[2] += perc
FX = None
pagos = [r for r in rows('3 Pagos') if r[1] and r[1] != 'Pago']
usd = sorted([(d(r[0]), i, r[6] / r[5]) for i, r in enumerate(pagos) if r[4] == 'USD' and N(r[5]) > 0])
FX = usd[-1][2]
def rates(prov, org):
    if org != 'Local': return 0, 0
    o = rate.get(prov)
    if o and o[0] > 0: return o[1] / o[0], o[2] / o[0]
    return DEF['Local'][2], DEF['Local'][3]
# 1. real
real = collections.defaultdict(lambda: [0, 0, 0, 0])
for r in pagos:
    k = int(r[0][:4]) * 100 + int(r[0][5:7]); amt = N(r[6]); f1 = (r[7] or '').split(',')[0].strip()
    if f1 and f1 in imp and imp[f1][3]:
        n, i, p, t = imp[f1]; sn, si = n / t, i / t
    else: sn, si = (1, 0)
    real[k][0] += amt * sn; real[k][1] += amt * si; real[k][2] += amt * max(0, 1 - sn - si)
for r in rows('6 Gastos de importación'):
    if r[1] and r[0] and str(r[0])[:2] == '20': real[int(r[0][:4]) * 100 + int(r[0][5:7])][3] += N(r[8])
# 2a facturas abiertas
fa = collections.defaultdict(lambda: [0, 0, 0])
for r in rows('2 Facturas abiertas'):
    if not r[2] or r[2] == 'Número': continue
    saldo = N(r[10]) * (FX if r[6] == 'USD' else 1); v = d(r[11])
    m = 1 if (v is None or v <= FEXP) else min(5, (v.year * 12 + v.month) - (YEAR * 12 + CUR) + 1)
    sn = N(r[7]) / N(r[8]) if N(r[8]) else 1
    t = imp.get(str(r[2]).strip()); si = t[1] / t[3] if t and t[3] else 1 - sn
    fa[m][0] += saldo * sn; fa[m][1] += saldo * si; fa[m][2] += saldo * max(0, 1 - sn - si)
# 2b OC: usa el entrante asignado y el mes de llegada que calcula el libro (Aux AB, AC) — verificado aparte por compare.py
ax = list(wb['Aux'].iter_rows(min_row=1, max_col=ci('AF'), values_only=True))
oc_rows = list(openpyxl.load_workbook(OCF, read_only=True, data_only=True).worksheets[0].iter_rows(values_only=True))
oc = collections.defaultdict(lambda: [0, 0, 0])
for i, r in enumerate(oc_rows):
    if i < 5 or not isinstance(r[0], int): continue
    a = ax[i]; asg, mes = N(a[ci('AB') - 1]), a[ci('AC') - 1]
    if asg <= 0: continue
    prov = str(r[4]).strip(); org = ORIG.get(prov, 'Local')
    ct = str(r[12] or '').replace('PROVEEDORES - ', '').strip()
    pc = cond.get(prov, ('', ''))
    sd = resdays(pc[1]); sd = sd if sd is not None else DEF[org][0]
    if ct: ant = 'anticip' in ct.lower()
    elif pc[0]: ant = 'anticip' in pc[0].lower()
    else: ant = DEF[org][1] == 1
    if ant: continue
    if not ct: days = sd
    elif 'contado' in ct.lower(): days = 0
    else:
        nums = [int(x) for x in re.findall(r'\d+', ct)]
        days = (nums[0] + nums[-1]) / 2 if nums else sd
    pm_ = min(5, mes + round(days / (365 / 12)))
    val = asg * N(ax[i][ci('AF') - 1]) if len(ax[i]) >= ci('AF') else 0
    iv, pc_ = rates(prov, org)
    oc[pm_][0] += val; oc[pm_][1] += val * iv; oc[pm_][2] += val * pc_
# 2c compras del presupuesto: desde columnas del motor (rd, o, q27d, em27) con condición recalculada aquí
c = json.load(open(SP + 'cols.json'))
K = ['sku', 'prov', 'ori', 'rd1', 'rd2', 'rd3', 'rd4', 'o1', 'o2', 'o3', 'o4', 'q27d', 'em27', 'dant', 'ddias', 'ivp', 'pcp', 'dn1', 'dn2', 'dn3', 'dn4']
pr = collections.defaultdict(lambda: [0, 0, 0]); bad = []
for r in wb['Cálculo SKU'].iter_rows(min_row=3, values_only=True):
    x = {k: r[ci(c[k]) - 1] for k in K}
    if not x['sku']: continue
    prov = (x['prov'] or '').strip(); org = x['ori']; porg = ORIG.get(prov, 'Local')
    pc = cond.get(prov, ('', '')) if porg == org else ('', '')
    if pc[1] == '': pc = ('', '')
    ant = ('anticip' in pc[0].lower()) if pc[0] else DEF[org][1] == 1
    days = resdays(pc[1]); days = days if days is not None else DEF[org][0]
    sh = round(days / (365 / 12))
    iv, pc_ = (rates(prov, org) if porg == org else ((DEF['Local'][2], DEF['Local'][3]) if org == 'Local' else (0, 0)))
    for j in range(1, 5):
        if ant: v = N(x[f'o{j}']) + (N(x['q27d']) if x['em27'] == j else 0)
        else: v = N(x[f'rd{j-sh}']) if j - sh >= 1 else 0
        pr[j][0] += v; pr[j][1] += v * iv; pr[j][2] += v * pc_
        if abs(v - N(x[f'dn{j}'])) > 1: bad.append((x['sku'], j, v, x[f'dn{j}']))
    if abs(iv - N(x['ivp'])) > 1e-6 or abs(pc_ - N(x['pcp'])) > 1e-6 or int(ant) != int(N(x['dant'])) or days != N(x['ddias']): bad.append((x['sku'], 'cond', ant, days, iv, pc_, x['dant'], x['ddias'], x['ivp'], x['pcp']))
# gastos proyectados: promedio jul-sep
gp = sum(real[YEAR * 100 + m][3] for m in (7, 8, 9)) / 3
fac = [17 / 21, 1, 1, 1]
# comparar con el libro
de = list(wb['Desembolsos'].iter_rows(values_only=True))
lab = {str(r[0]).strip(): r for r in de if r and r[0]}
out = []
def chk(name, a, b, tol=2):
    ok = abs((a or 0) - (b or 0)) <= tol + abs(b or 0) * 1e-9
    out.append((ok, name, round(a or 0), round(b or 0)))
for m in range(1, 13):
    k = YEAR * 100 + m
    for i, nm in enumerate(['Materia prima (neto)', 'IVA', 'Percepciones', 'Gastos de importación']):
        row = [r for r in de[5:15] if r[0] == nm][0]
        chk(f'real {nm} m{m}', row[m], real[k][i])
sec = None; got = {}
for r in de[19:40]:
    if not r[0]: continue
    t = str(r[0])
    if t.startswith('Facturas'): sec = 'fa'
    elif t.startswith('OC emitidas'): sec = 'oc'
    elif t.startswith('Compras del'): sec = 'pr'
    elif t.startswith('Gastos de importación'): got[('gi',)] = r[1:5]; sec = None
    elif sec and t.strip() in ('Materia prima (neto)', 'IVA', 'Percepciones'):
        got[(sec, t.strip())] = r[1:5]
for sec, src in (('fa', fa), ('oc', oc), ('pr', pr)):
    for i, nm in enumerate(['Materia prima (neto)', 'IVA', 'Percepciones']):
        for j in range(1, 5): chk(f'{sec} {nm} m{j}', got[(sec, nm)][j - 1], src[j][i])
for j in range(1, 5): chk(f'gastos proy m{j}', got[('gi',)][j - 1], gp * fac[j - 1])
print('TC', FX, 'mismatches SKU', len(bad), bad[:5])
fails = [o for o in out if not o[0]]
print('chequeos', len(out), 'fallas', len(fails))
for f in fails[:20]: print(f)
print('real', {k: [round(x / 1e6, 1) for x in v] for k, v in sorted(real.items())})
print('fa', {k: [round(x / 1e6, 1) for x in v] for k, v in sorted(fa.items())})
print('oc', {k: [round(x / 1e6, 1) for x in v] for k, v in sorted(oc.items())})
print('pr', {k: [round(x / 1e6, 1) for x in v] for k, v in sorted(pr.items())}, 'gi', round(gp / 1e6, 1))
