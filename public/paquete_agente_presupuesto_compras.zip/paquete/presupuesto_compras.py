# -*- coding: utf-8 -*-
"""
Motor del Presupuesto de Compras de Materias Primas — Frontera Living S.A.
===========================================================================

Reproduce en Python, desde las 3 exportaciones de Odoo, el mismo cálculo que el libro
"Presupuesto_Compras_MP" (hoja Cálculo SKU). Verificado contra el libro: mismas cifras
SKU por SKU.

Entradas:
  - Base de datos (xlsx): Nombre en pantalla | Cantidad disponible para uso | Entrante | Saliente |
    Cantidad pronosticada | Categoría del producto | Proveedores | Costo
    (una fila por producto; las filas siguientes sin nombre son proveedores adicionales)
  - Historial de consumo (xlsx): fila 2 = meses ("agosto 2026"...), desde la fila 5 un insumo por fila
  - Plan (xlsx): el archivo IN_Plan (Concepto | Enero ... Diciembre | Enero (año sig.)) o la Rendición con las filas
    "PRODUCCION REALES", "PRODUCCION CONSENSUADO", "VENTAS CONSENSUADO", "dias habil del mes", "Dias habil trascurrido en el mes"

Salidas:
  - calcular(...)      -> DataFrame con una fila por SKU y todas las columnas del cálculo
  - tabla_larga(...)   -> DataFrame con una fila por SKU y mes (lo mismo que la hoja Exportar)

Uso por línea de comandos:
  python presupuesto_compras.py --base IN_Base.xlsx --consumo IN_Consumo.xlsx \
      --rendicion IN_Plan.xlsx --oc oc_pendientes_mp.xlsx --corte 9 --anio 2026 --dias-transcurridos 4 \\
      --fecha-exportacion 2026-10-06 --version 2026-10-06 --salida presupuesto.csv

Las reglas que mantiene Compras (hoja Parámetros del libro: supuestos, reglas y proveedores) están en CONFIG.
Si cambian en el libro, hay que actualizarlas acá.
Meses del horizonte después de diciembre: se usa CONFIG['plan_enero_siguiente'] y, si está vacío, diciembre.
"""
import math, argparse
import numpy as np
import pandas as pd
from openpyxl import load_workbook

MESES = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre']

# ----------------------------------------------------------------------------- CONFIG
CONFIG = {
    # --- Supuestos
    'sommier_pct_ventas': 0.15,          # bases de sommier = % de ventas de colchones
    'pocket_x18_mes': 600,               # plan Pocket x18 (u/mes)
    'eps_semana': 150,                   # plan EPS (u/semana)
    'semanas_mes': 52 / 12,
    'umbral_A': 0.80, 'umbral_B': 0.95,  # ABC sobre consumo proyectado valorizado
    'dias_por_semana': 7,
    'umbral_tendencia': 0.30,            # ± sobre promedio 4 meses
    # plan del mes siguiente al horizonte (cobertura al cierre). None = usa el último mes del horizonte
    'plan_mes_siguiente': {'prod_colchones': None, 'prod_sillones': None, 'ventas_colchones': None},
    # plan de enero del año siguiente (la Rendición es anual). None = se usa diciembre
    'plan_enero_siguiente': {'prod_colchones': None, 'prod_sillones': None, 'ventas_colchones': None},
    # --- Política por origen
    'origenes': {  # lead time (días corridos), stock de seguridad mínimo (semanas), ciclo de compra (meses)
        'Local':  {'lead_dias': 14, 'ss_min': 0, 'ciclo': 1},
        'Brasil': {'lead_dias': 40, 'ss_min': 4, 'ciclo': 1},
        'China':  {'lead_dias': 90, 'ss_min': 6, 'ciclo': 4},
    },
    'ss_abc': {'A': 1, 'B': 2, 'C': 4},          # stock de seguridad por clase (semanas)
    'ciclo_abc': {'A': 2, 'B': 3, 'C': 4},       # margen hasta el máximo (semanas), solo compra mensual
    'ss_critico': 4,
    # --- Reglas
    'linea_por_categoria': {'Tela Colchon': 'Colchones', 'TNT': 'Colchones', 'Bases': 'Colchones', 'Alambre': 'Colchones',
                            'Cartones': 'Ambos', 'Mercería': 'Ambos', 'Químicos': 'Ambos'},  # resto: Living; Nylon virgen: Colchones
    'colecciones': {  # inicio del nombre -> colección (Tela Living). Si no coincide: primera palabra
        'BOUCLE LENNY': 'BOUCLE LENNY', 'BOUCLE NOVA': 'BOUCLE NOVA', 'BOUCLE 5#': 'BOUCLE #5', 'PANA BLONDIE': 'PANA BLONDIE',
        'PANA RIFF': 'PANA RIFF', 'PANA CROSS': 'PANA CROSS', 'PEVECRON LE MANS': 'PEVECRON LE MANS', 'VELVET TWIST': 'VELVET TWIST',
        'CUERO SILK / STIK': 'CUERO SILK / STIK', 'DENSE HERMES': 'DENSE HERMES', 'FORM / GIVENCHY': 'GIVENCHY', 'TC SUNNY': 'SUNNY'},
    'prefijos_tela_living': ['ALPHA', 'BOUCLE', 'BRUMA', 'CORANO', 'CUERO', 'CUEROTEX', 'DENSE', 'FLOW', 'FLOYD', 'FORM', 'JAGUAR', 'LIO',
                             'MILANO', 'ORION', 'PANA', 'PEVECRON', 'SHOT', 'SYDNEY', 'TC', 'VELVET', 'CAMBRIDGE', 'MONT', 'NAC'],
    'quimicos_principales': ['TDI (DI ISIOCANATO DE TOLUENO)', 'VORANOL (POLIOL)', 'VORANOL 3943 (COPO)'],
    'colecciones_discontinuadas': [],
    # --- Proveedores (los no listados son Local)
    'origen_proveedor': {
        'Foshan Shunbang Import & Export Co., Ltd.': 'China', 'Foshan Win Star Furniture Accessory Co., Limited': 'China',
        'Guangdong Quanli Sleep Technology Co., Ltd.': 'China', 'HUZHOU FORNICE TEXTILE CO.,LTD': 'China',
        'Jiangsu SOHO Innovation & Technology Group Co., Ltd.': 'China', 'Yuyao Dafa Chemical Fiber Co., Ltd.': 'China',
        'ZHE JIANG UNITED SERVICE CORPORATION LTD.': 'China', 'ZHEIJIANG QLNGSONG LIGHT TEXTILE CO.,LTD': 'China',
        'BEICHI HARDWARE': 'China', 'COLORFLEX ESTAMPARIA LTDA': 'Brasil', 'FITAFLEX INDUSTRIA E COMERCIO LTDA': 'Brasil',
    },
    # --- Excepciones por SKU: metodo, critico, costo, consumo_forzado, origen, respaldo
    'excepciones': {
        'GRAMPA CLIP CL34 - 22*17': {'costo': 15},
        'GRAMPA CLIP CC32 - 11*14': {'costo': 12.15},
        'V406': {'consumo_forzado': 1900, 'origen': 'China', 'respaldo': 'Brasil'},
        'V1551': {'origen': 'China', 'respaldo': 'Brasil'}, 'V1554': {'origen': 'China', 'respaldo': 'Brasil'},
        'V1553': {'origen': 'China', 'respaldo': 'Brasil'}, 'V1558': {'origen': 'China', 'respaldo': 'Brasil'},
        'V368': {'origen': 'China', 'respaldo': 'Brasil'},
        **{t: {'origen': 'Brasil'} for t in ['BASE R POCKET 135X185X18 S/M S/E', 'BASE R POCKET 155X195X18 S/M S/E',
                                             'BASE R POCKET 175X195X18 S/M S/E', 'BASE R POCKET 195X195X18 S/M S/E',
                                             'BASE R POCKET 75X185X18 S/M S/E', 'BASE R POCKET 85X185X18 S/M S/E', 'BASE R POCKET 95X185X18 S/M S/E']},
        **{t: {'metodo': 'Discontinuado'} for t in ['CUERO SILK / STIK #3', 'DENSE HERMES 20#', 'FORM / GIVENCHY 4#']},
        # líneas discontinuadas de China (Compras, 07/10/2026): se consume el stock y se archivan
        **{t: {'metodo': 'Discontinuado'} for t in ['BASE R POCKET 175X195X23 S/M S/E', 'BASE R POCKET 75X185X23 S/M S/E', 'BASE R POCKET 85X185X23 S/M S/E', 'BOUCLE NOVA #15', 'BOUCLE NOVA #16', 'BOUCLE NOVA #18', 'BOUCLE NOVA #2', 'BOUCLE NOVA #21', 'BOUCLE NOVA #3', 'BOUCLE NOVA #4', 'BOUCLE NOVA #5', 'BOUCLE NOVA #8', 'CUERO SILK / STIK #2', 'CUERO SILK / STIK #7', 'CUERO SILK / STIK #8', 'CUERO SILK / STIK #9', 'DENSE HERMES 10#', 'DENSE HERMES 18#', 'DENSE HERMES 21#', 'DENSE HERMES 22#', 'DENSE HERMES 23#', 'DENSE HERMES 5#', 'FORM / GIVENCHY 1#', 'FORM / GIVENCHY 10#', 'FORM / GIVENCHY 11#', 'FORM / GIVENCHY 14#', 'FORM / GIVENCHY 6#', 'FORM / GIVENCHY 8#', 'FORM / GIVENCHY 9#']},
        **{t: {'origen': 'China', 'respaldo': 'Local'} for t in ['ENGANCHADORES (PAR)', 'MECANISMO EXTENSIBLE ASIENTO (PAR)', 'MOVI RESPALDO (H5)', 'ANCLAJE COCODRILO MACHO', 'ANCLAJE COCODRILO HEMBRA']},
        **{t: {'origen': 'China', 'respaldo': 'Ninguno'} for t in ['CONJUNTO MOTOR 516D (PIN / CLIP)', 'LATERAL DERECHO MEC. 516D', 'LATERAL IZQUIERDO MEC. 516D', 'RESORTE 516D', 'TUBO ACERO MEC. 516D L537,8', 'TUBO ACERO MEC. 516D L671,8']},
        **{t: {'metodo': 'Agotar stock', 'origen': 'China', 'respaldo': 'Ninguno'} for t in ['BRAZO METALICO DERECHO MEC. 8102D', 'BRAZO METALICO IZQUIERDO MEC. 8102D', 'CONJUNTO MOTOR 8102D (MOTOR / TORNILLO)', 'GATILLO DERECHO MEC. 8102M', 'GATILLO LATERAL IZQUIERDO 8102M', 'LATERAL DERECHO MEC. 8102D', 'LATERAL DERECHO MEC. 8102M', 'LATERAL IZQUIERDO MEC. 8102D', 'LATERAL IZQUIERDO MEC. 8102M', 'RESORTE 8102D', 'RESORTE 8102M', 'RESORTE BLOQUEO 8102M', 'TUBO ACERO MEC. 8102M L482,6', 'TUBO ACERO MEC. 8102M L568,4']},
    },
}
ORDEN_ORIGEN = {'Local': 1, 'Brasil': 2, 'China': 3}
NOMBRE_ORIGEN = {v: k for k, v in ORDEN_ORIGEN.items()}


# ----------------------------------------------------------------------------- lectura
def leer_base(path):
    b = pd.read_excel(path)
    rows, provs, cur = [], {}, None
    for _, r in b.iterrows():
        nm = r['Nombre en pantalla']
        if isinstance(nm, str) and nm.strip() and isinstance(r['Categoría del producto'], str) and r['Categoría del producto'].strip():
            rows.append(r); cur = nm.strip(); provs[cur] = []
        elif isinstance(nm, str) and nm.strip():
            cur = None
        if cur is not None and isinstance(r['Proveedores'], str) and r['Proveedores'].strip():
            provs[cur].append(r['Proveedores'].strip())
    d = pd.DataFrame(rows).reset_index(drop=True)
    d['sku'] = d['Nombre en pantalla'].str.strip()
    d['proveedores'] = d.sku.map(provs)
    return d

def leer_consumo(path):
    return pd.read_excel(path, header=None)

def leer_rendicion(path):
    """Acepta la Rendición o el archivo IN_Plan (formato de la hoja IN_Plan: Concepto | Enero ... Diciembre | Enero (año sig.))."""
    ws = load_workbook(path, read_only=True, data_only=True).worksheets[0]
    R = [list(r) for r in ws.iter_rows(values_only=True)]
    if R and R[0] and isinstance(R[0][0], str) and R[0][0].strip().lower() == 'concepto':
        P = {r[0].strip().lower(): list(r[1:13]) + [None] * (12 - len(r[1:13])) for r in R if r and isinstance(r[0], str)}
        g = lambda k: P.get(k.lower(), [None] * 12)
        filas = [('dias habil del mes', g('Días hábiles del mes')), ('Dias habil trascurrido en el mes', g('Días hábiles transcurridos')),
                 ('PRODUCCION REALES', [None] * 12), ('', g('Producción real Sillones equiv.')), ('', g('Producción real Colchones')),
                 ('PRODUCCION CONSENSUADO', [None] * 12), ('', g('Producción consensuada Sillones equiv.')), ('', g('Producción consensuada Colchones')),
                 ('VENTAS CONSENSUADO', [None] * 12), ('', [None] * 12), ('', g('Ventas consensuadas Colchones'))]
        R = [[None, lab, None] + vals for lab, vals in filas]
    return R


def leer_oc(path):
    """OC abiertas de MP (formato de Facu: encabezado en la fila donde la columna A dice 'ID producto')."""
    ws = load_workbook(path, read_only=True, data_only=True).worksheets[0]
    R = [list(r) for r in ws.iter_rows(values_only=True)]
    out = []
    for i, r in enumerate(R):
        if r and isinstance(r[0], (int, float)) and not isinstance(r[0], bool):
            out.append(dict(fila=i + 1, n=str(r[1] or '').strip(), orden=r[3], prov=r[4], fecha=r[6], pend=max(0.0, float(r[9] or 0))))
    return out

def _fecha(v, defecto):
    import datetime as _dt
    if isinstance(v, _dt.datetime): return v.date()
    if isinstance(v, _dt.date): return v
    try: return _dt.date(int(str(v)[:4]), int(str(v)[5:7]), int(str(v)[8:10]))
    except Exception: return defecto

def entrante_por_mes(skus, entrante, oc, fexp, anio, mes_curso):
    """Reparte el entrante de la base entre las OC más recientes de cada SKU y lo ubica por mes de llegada.
    Vencidas (fecha <= fexp) y entrante sin OC -> mes 2. Devuelve dict sku -> dict(e1..e5, ev, esf, oca, ocp)."""
    by = {}
    for l in oc:
        l = dict(l); l['f'] = _fecha(l['fecha'], fexp); by.setdefault(l['n'], []).append(l)
    res = {}
    for s, ent in zip(skus, entrante):
        lines = sorted(by.get(s, []), key=lambda l: (-l['f'].toordinal(), l['fila']))
        e = [0.0] * 6; ev = 0.0; acum = 0.0; oca = 0.0
        for l in lines:
            a = max(0.0, min(l['pend'], ent - acum)); acum += l['pend']; oca += a
            if l['f'] <= fexp: b = 2; ev += a
            else: b = max(1, min(5, (l['f'].year * 12 + l['f'].month) - (anio * 12 + mes_curso) + 1))
            e[b] += a
        esf = max(0.0, ent - oca); e[2] += esf
        res[s] = dict(e1=e[1], e2=e[2], e3=e[3], e4=e[4], e5=e[5], ev=ev, esf=esf, oca=oca, ocp=sum(l['pend'] for l in lines))
    return res

def meses_sin_llegada(lt_semanas, dias_restantes):
    import math as _m
    if lt_semanas == 0: return 0
    x = max(0, round(lt_semanas * 7) - dias_restantes) / (365 / 12)
    return int(_m.ceil(x - 1e-12))

# ----------------------------------------------------------------------------- cálculo
def calcular(base, consumo, rendicion, corte, anio, dias_transcurridos=None, cfg=CONFIG, oc=None, fecha_exportacion=None):
    """base: DataFrame de leer_base; consumo: DataFrame de leer_consumo; rendicion: filas de leer_rendicion.
    corte: último mes cerrado (1-12). dias_transcurridos: días hábiles del mes en curso a la fecha de la exportación
    (None = el de Rendición)."""
    C = cfg; semmes = C['semanas_mes']; EXC = C['excepciones']
    d = base.copy()
    cat = d['Categoría del producto'].str.strip()
    d['cat'] = np.where(cat == 'Materia Prima', 'Otros', cat.str.replace('Materia Prima / ', '', regex=False))
    d['prov'] = d['Proveedores'].fillna('').astype(str).str.strip()
    d['disp'] = pd.to_numeric(d['Cantidad disponible para uso'], errors='coerce').fillna(0)
    d['ent'] = pd.to_numeric(d['Entrante'], errors='coerce').fillna(0)
    d['costo'] = pd.to_numeric(d['Costo'], errors='coerce').fillna(0)
    d['costo'] = [EXC.get(s, {}).get('costo') or c for s, c in zip(d.sku, d.costo)]
    d['forz'] = [EXC.get(s, {}).get('consumo_forzado') or 0 for s in d.sku]
    d['crit'] = [bool(EXC.get(s, {}).get('critico')) for s in d.sku]
    d['pos'] = d.disp + d.ent
    d['lin'] = [('Colchones' if 'NYLON VIRGEN' in s.upper() else 'Living') if c == 'Nylon' else C['linea_por_categoria'].get(c, 'Living')
                for s, c in zip(d.sku, d.cat)]
    # origen por prioridad entre todos los proveedores (China > Brasil > Local); respaldo = el siguiente
    ori, resp = [], []
    for s, pl in zip(d.sku, d.proveedores):
        rks = sorted({ORDEN_ORIGEN[C['origen_proveedor'].get(p, 'Local')] for p in (pl or [])}, reverse=True) or [1]
        e = EXC.get(s, {})
        if e.get('origen'):
            r1 = ORDEN_ORIGEN[e['origen']]
            r2 = (0 if e['respaldo'] == 'Ninguno' else ORDEN_ORIGEN[e['respaldo']]) if e.get('respaldo') else (0 if r1 < 3 else max([x for x in rks if x < r1], default=0))
        else:
            r1 = rks[0]; r2 = max([x for x in rks if x < r1], default=0)
        ori.append(NOMBRE_ORIGEN[r1]); resp.append('' if r1 < 3 else (NOMBRE_ORIGEN[r2] if r2 else 'Sin respaldo'))
    d['ori'] = ori; d['resp'] = resp
    # colección y color
    def coll(s, c):
        if c != 'Tela Living': return ('', '')
        m = [a for a in C['colecciones'] if s.upper().startswith(a)]
        if m:
            a = max(m, key=len); return (C['colecciones'][a], s[len(a):].strip())
        w = s.split(' ', 1); return (w[0], w[1].strip() if len(w) > 1 else '')
    cc = [coll(s, c) for s, c in zip(d.sku, d.cat)]
    d['col'] = [x[0] for x in cc]; d['colr'] = [x[1] for x in cc]
    # método y driver
    def met(s, c, cost, col):
        if EXC.get(s, {}).get('metodo'): return EXC[s]['metodo']
        if s in C['quimicos_principales']: return 'Químico principal'
        if cost == 0: return 'Consignado'
        if c == 'Tela Living' and col in C['colecciones_discontinuadas']: return 'Discontinuado'
        if c == 'Bases':
            u = s.upper()
            if 'SOMMIER' in u: return 'Sommier'
            if 'EPS' in u: return 'EPS'
            if 'POCKET' in u and 'X18 ' in (u + ' '): return 'Pocket x18'
            return 'Discontinuado'
        if c in ('Grampas', 'Alambre'): return 'Promedio'
        if c == 'Tela Living': return 'Tela Living'
        return 'Coeficiente'
    d['met'] = [met(s, c, k, cl) for s, c, k, cl in zip(d.sku, d.cat, d.costo, d['col'])]
    def drv(m, l, fz):
        if fz > 0: return 'Mes'
        if m in ('Coeficiente', 'Agotar stock'): return {'Colchones': 'Prod Colchones', 'Living': 'Prod Sillones'}.get(l, 'Prod Total')
        if m == 'Químico principal': return 'Prod Total'
        return {'Promedio': 'Mes', 'Sommier': 'Sommier', 'Pocket x18': 'Pocket x18', 'EPS': 'EPS', 'Tela Living': 'Tela Living'}.get(m, 'Sin proyección')
    d['drv'] = [drv(m, l, f) for m, l, f in zip(d.met, d.lin, d.forz)]
    # consumo: 4 meses cerrados hasta el corte
    h = consumo; hdrs = list(h.iloc[1]); ci = hdrs.index(f'{MESES[corte-1]} {anio}')
    cons = {}
    for _, r in h.iloc[4:].iterrows():
        n = str(r.iloc[0]).strip()
        vals = [pd.to_numeric(r.iloc[ci - 3 + j], errors='coerce') for j in range(4)]
        cons[n] = [0.0 if pd.isna(v) else float(v) for v in vals]
    Cm = np.array([cons.get(s, [0, 0, 0, 0]) for s in d.sku])
    d[['c1', 'c2', 'c3', 'c4']] = Cm; d['c4t'] = Cm.sum(axis=1); d['c3t'] = Cm[:, 1:].sum(axis=1)
    inbase = set(d.sku)
    m_arch = sum(sum(v) for n, v in cons.items() if n not in inbase and n.split(' ')[0] in C['prefijos_tela_living'])
    # rendición
    R = rendicion
    def fila(lbl):
        for i, r in enumerate(R):
            if isinstance(r[1], str) and r[1].strip().lower() == lbl.lower(): return i
        raise KeyError(lbl)
    def val(i, mes):
        v = R[i][2 + mes] if len(R[i]) > 2 + mes else None
        return float(v) if isinstance(v, (int, float)) else 0.0
    pr, pc, vc = fila('PRODUCCION REALES'), fila('PRODUCCION CONSENSUADO'), fila('VENTAS CONSENSUADO')
    dhm = val(fila('dias habil del mes'), corte + 1)
    if dias_transcurridos is None: dias_transcurridos = val(fila('Dias habil trascurrido en el mes'), corte + 1)
    frac = max(0, dhm - dias_transcurridos) / dhm if dhm else 0
    calm = [corte - 3 + j for j in range(4)]
    realC = [val(pr + 2, m) for m in calm]; realS = [val(pr + 1, m) for m in calm]
    hm = [corte + 1 + j for j in range(4)]
    fac = [frac, 1, 1, 1]
    pe = C.get('plan_enero_siguiente') or {}
    J = (pe.get('prod_colchones') or 0, pe.get('prod_sillones') or 0, pe.get('ventas_colchones') or 0)
    def serie(off, ji):   # hasta diciembre: plan; enero sig.: plan de enero o diciembre; después: el mes anterior
        out = []
        for m in hm:
            if m <= 12: out.append(val(off, m))
            elif m == 13 and J[ji] > 0: out.append(J[ji])
            else: out.append(out[-1] if out else 0)
        return out
    planC = serie(pc + 2, 0); planS = serie(pc + 1, 1); ventC = serie(vc + 2, 2)
    m5 = hm[-1] + 1; ps = C['plan_mes_siguiente']
    if m5 <= 12 and val(pc + 2, m5) > 0: n5 = (val(pc + 2, m5), val(pc + 1, m5), val(vc + 2, m5))
    elif m5 == 13 and J[0] > 0: n5 = J
    else: n5 = (ps['prod_colchones'] if ps['prod_colchones'] is not None else planC[-1],
                ps['prod_sillones'] if ps['prod_sillones'] is not None else planS[-1],
                ps['ventas_colchones'] if ps['ventas_colchones'] is not None else ventC[-1])
    planC5, planS5, ventC5, fac5 = planC + [n5[0]], planS + [n5[1]], ventC + [n5[2]], fac + [1]
    calib = {'Prod Colchones': sum(realC), 'Prod Sillones': sum(realS), 'Prod Total': sum(realC) + sum(realS), 'Mes': 4, 'Sin proyección': 1}
    last = {'Prod Colchones': realC[-1], 'Prod Sillones': realS[-1], 'Prod Total': realC[-1] + realS[-1], 'Mes': 1, 'Sin proyección': 1}
    for k in ['Sommier', 'Pocket x18', 'EPS', 'Tela Living']:
        calib[k] = d.loc[d.drv == k, 'c4t'].sum(); last[k] = 0
    mps = (calib['Tela Living'] + m_arch) / sum(realS) if sum(realS) else 0
    def dval(k, j):
        f = fac5[j]
        return {'Prod Colchones': planC5[j] * f, 'Prod Sillones': planS5[j] * f, 'Prod Total': (planC5[j] + planS5[j]) * f, 'Mes': f,
                'Sommier': C['sommier_pct_ventas'] * ventC5[j] * f, 'Pocket x18': C['pocket_x18_mes'] * f,
                'EPS': C['eps_semana'] * semmes * f, 'Tela Living': mps * planS5[j] * f, 'Sin proyección': 0}[k]
    import datetime as _dt, calendar as _cal
    fexp = fecha_exportacion or _dt.date.today()
    # entrante de la base ubicado por mes con las fechas de las OC abiertas (antes de proyectar: Agotar stock lo usa)
    EM = entrante_por_mes(list(d.sku), list(d.ent), oc or [], fexp, anio, corte + 1)
    for c in ['e1', 'e2', 'e3', 'e4', 'e5', 'ev', 'esf', 'oca', 'ocp']: d[c] = [EM[x][c] for x in d.sku]
    out = []
    for _, r in d.iterrows():
        k = r.drv; cal = calib[k]; calu = last[k]
        coefb = r.c4t / cal if cal else 0; coefu = r.c4 / calu if calu else 0
        if r.c4t == 0 or k == 'Sin proyección': rat = None
        elif calu > 0: rat = coefu / coefb if coefb else None
        else: rat = r.c4 / (r.c4t / 4)
        tend = '' if rat is None else ('Creciente' if rat >= 1 + C['umbral_tendencia'] else ('Decreciente' if rat <= 1 - C['umbral_tendencia'] else 'Estable'))
        if r.forz > 0: coef = r.forz
        elif tend == 'Creciente' and r.met in ('Coeficiente', 'Químico principal') and sum(v > 0 for v in (r.c1, r.c2, r.c3, r.c4)) >= 2: coef = max(coefb, coefu)
        else: coef = coefb
        p = [coef * dval(k, j) for j in range(5)]
        if r.met == 'Agotar stock':   # se consume solo hasta agotar disponible + entrante; no se compra
            av = r.disp; ee_ = [r.e1, r.e2, r.e3, r.e4]
            for j in range(5):
                if j < 4: av += ee_[j]
                p[j] = max(0.0, min(p[j], av)); av -= p[j]
        out.append(dict(tend=tend, coef=coef, p1=p[0], p2=p[1], p3=p[2], p4=p[3], p5=p[4]))
    d = pd.concat([d, pd.DataFrame(out)], axis=1)
    d['pt'] = d[['p1', 'p2', 'p3', 'p4']].sum(axis=1); d['pv'] = d.pt * d.costo
    tot = d.pv.sum()
    pct = [d.loc[d.pv >= v, 'pv'].sum() / tot if v > 0 else None for v in d.pv]
    d['abc'] = ['Sin consumo' if v <= 0 else ('A' if q <= C['umbral_A'] else ('B' if q <= C['umbral_B'] else 'C')) for v, q in zip(d.pv, pct)]
    O_ = C['origenes']
    d['lt'] = [O_[o]['lead_dias'] / 7 for o in d.ori]
    d['ltb'] = [O_[r]['lead_dias'] / 7 if r in O_ else 0 for r in d.resp]
    d['cic'] = [O_[o]['ciclo'] for o in d.ori]
    d['ss'] = [0 if (a == 'Sin consumo' or m_ == 'Agotar stock') else max(C['ss_abc'][a], O_[o]['ss_min'], C['ss_critico'] if cr else 0) for a, o, cr, m_ in zip(d.abc, d.ori, d.crit, d.met)]
    d['obs'] = [0 if (a == 'Sin consumo' or m_ == 'Agotar stock') else l + s for a, l, s, m_ in zip(d.abc, d['lt'], d.ss, d.met)]
    d['mxs'] = [0 if o == 0 else (s + c * semmes + (l if rs in ('Local', 'Brasil') else 0) if c > 1 else o + C['ciclo_abc'].get(a, 0)) for o, a, s, c, l, rs in zip(d.obs, d.abc, d.ss, d.cic, d['lt'], d.resp)]
    d['idw'] = [0 if o == 0 else (s + c * semmes / 2 if c > 1 else o) for o, s, c in zip(d.obs, d.ss, d.cic)]
    sem = [f * semmes for f in fac5]
    W = np.array([[r[f'p{j+2}'] / sem[j + 1] if sem[j + 1] else 0 for j in range(4)] for _, r in d.iterrows()])
    # meses en que ninguna compra nueva puede llegar (según los días corridos que quedan del mes en curso)
    rem = _cal.monthrange(fexp.year, fexp.month)[1] - fexp.day
    keys = [(anio + (m - 1) // 12) * 100 + (m - 1) % 12 + 1 for m in hm]
    rdes = [EXC.get(sx, {}).get('reemplazo_desde') or 0 for sx in d.sku]
    d['cut'] = [next((j + 1 for j, kk in enumerate(keys) if kk >= rd), 0) if rd else 0 for rd in rdes]
    d['rnom'] = [EXC.get(sx, {}).get('reemplazado_por') or '' for sx in d.sku]
    d['lm'] = [meses_sin_llegada(x, rem) for x in d['lt']]
    d['lmb'] = [meses_sin_llegada(x, rem) for x in d['ltb']]
    n = len(d); RG, CH, BK, FA, EN = (np.zeros((n, 4)) for _ in range(5))
    for i, r in d.iterrows():
        pp = [r.p1, r.p2, r.p3, r.p4, r.p5]; ee = [r.e1, r.e2, r.e3, r.e4]; stock = r.disp; arrived = False
        for k in range(4):
            start = stock if (k + 1) != r.cut else 0.0; raw = start + ee[k] - pp[k]; arrived_before = arrived
            if r.cic > 1:   # compra por ciclo (China)
                SSk = r.ss * W[i, k]; ch = 0.0
                if (k + 1) >= r.lm + 1 and not arrived and raw < SSk:
                    months = [pp[j] if j < 4 else pp[4] for j in range(k, k + int(r.cic))]
                    ecy = sum(ee[j] for j in range(k, 4) if j <= k + r.cic - 1)
                    ch = max(0.0, sum(months) + r.ss * W[i, 3] - start - ecy); arrived = arrived or ch > 0
                gap = max(0.0, SSk - raw - ch)
                if r.resp in ('Local', 'Brasil'):
                    if (k + 1) > r.lmb and gap > 0:   # lote local que cubre hasta la próxima llegada de China
                        nxt = next((j + 1 for j in range(k + 1, 4) if ee[j] > 0), 5)
                        A_ = min(nxt, r.lm + 1 if (not arrived_before and r.lm + 1 > k + 1) else 5)
                        cov = sum(pp[j] - ee[j] for j in range(k, 4) if j + 1 < A_)
                        BK[i, k] = max(0.0, cov + r.ss * W[i, max(1, A_ - 1) - 1] - start - ch)
                    else: BK[i, k] = 0.0
                else: FA[i, k] = gap
                CH[i, k] = ch; stock = raw + ch + BK[i, k]
            else:           # compra mensual: cada mes cierra en su objetivo, desde el primer mes en que puede llegar
                RG[i, k] = 0.0 if (k + 1) <= r.lm else max(0.0, r.obs * W[i, k] - raw); stock = raw + RG[i, k]
            EN[i, k] = stock
    Rm = RG + CH + BK
    d['mag'] = [(next((k + 1 for k in range(4) if EN[i_, k] <= 0.001), 0) if m_ == 'Agotar stock' else 0) for i_, m_ in enumerate(d.met)]
    d['obso'] = [0.0 if c_ == 0 else max(0.0, r_.disp if c_ == 1 else EN[i_, c_ - 2]) for i_, (c_, r_) in enumerate(zip(d.cut, d.itertuples()))]
    for j in range(4):
        d[f'rg{j+1}'] = RG[:, j]; d[f'ch{j+1}'] = CH[:, j]; d[f'bk{j+1}'] = BK[:, j]; d[f'fal{j+1}'] = FA[:, j]; d[f'en{j+1}'] = EN[:, j]
        d[f'r{j+1}'] = Rm[:, j]; d[f'rd{j+1}'] = Rm[:, j] * d.costo
    d['rt'] = Rm.sum(axis=1); d['rdt'] = d.rt * d.costo
    O = np.zeros((n, 5))
    for i in range(n):
        for j in range(4):
            e = j - d.lm[i]; O[i, 0 if e < 0 else e + 1] += RG[i, j] + CH[i, j]
            e = j - d.lmb[i]; O[i, 0 if e < 0 else e + 1] += BK[i, j]
    for j in range(5): d[f'o{j}u'] = O[:, j]; d[f'o{j}'] = O[:, j] * d.costo
    lmu = [lb if (c > 1 and rs in ('Local', 'Brasil')) else lm_ for lb, lm_, c, rs in zip(d.lmb, d.lm, d.cic, d.resp)]
    d['o0u'] = [max([0.0] + [r.ss * W[i, k] - EN[i, k] for k in range(4) if k < lmu[i]]) for i, r in d.iterrows()]
    d['o0'] = d.o0u * d.costo
    q27, em27 = [], []
    for i, r in d.iterrows():
        nn = 0
        if r.cic > 1 and CH[i].sum() == 0 and r.p5 > 0 and r.met != 'Agotar stock':
            nn = max(1, int(math.floor((EN[i, 3] - r.ss * W[i, 3]) / r.p5)) + 1)
        em = 4 + nn - r.lm if nn else 0
        em = em if 1 <= em <= 4 else 0
        em27.append(em); q27.append(max(0.0, r.cic * r.p5 + r.ss * W[i, 3] - (EN[i, 3] - (nn - 1) * r.p5)) if em else 0.0)
    d['q27'] = q27; d['em27'] = em27
    d['qm'] = [next((k + 1 for k in range(4) if EN[i, k] < 0), 0) for i in range(n)]
    d.attrs['meses'] = [(f'{anio + (m - 1) // 12}-{(m - 1) % 12 + 1:02d}', MESES[(m - 1) % 12] + (' (año sig.)' if m > 12 else '')) for m in hm]
    return d


def tabla_larga(d, version=''):
    """Una fila por SKU y mes: el mismo contenido que la hoja Exportar del libro."""
    rows = []
    for _, r in d.iterrows():
        for j, (ym, nom) in enumerate(d.attrs['meses'], start=1):
            rows.append({'Versión': version, 'Mes (AAAA-MM)': ym, 'Mes': nom, 'SKU': r['sku'], 'Categoría': r['cat'],
                         'Línea': r['lin'], 'Proveedor (1° en Odoo)': r['prov'], 'Origen': r['ori'], 'Respaldo': r['resp'],
                         'Clase ABC': r.abc, 'Costo unitario ($)': r.costo, 'Llegada (u)': r[f'r{j}'], 'Llegada ($)': r[f'rd{j}'],
                         'Regular (u)': r[f'rg{j}'], 'Importación China (u)': r[f'ch{j}'], 'Respaldo (u)': r[f'bk{j}'],
                         'Emitir orden (u)': r[f'o{j}u'], 'Emitir orden ($)': r[f'o{j}'], 'Faltante bajo seguridad antes de poder recibir (u)': r['o0u'] if j == 1 else 0,
                         'Consumo proyectado (u)': r[f'p{j}'], 'Déficit sin respaldo (u)': r[f'fal{j}'], 'Entrante que llega (u)': r[f'e{j}']})
    return pd.DataFrame(rows)


if __name__ == '__main__':
    ap = argparse.ArgumentParser(description='Presupuesto de compras de materias primas')
    ap.add_argument('--base', required=True); ap.add_argument('--consumo', required=True); ap.add_argument('--rendicion', '--plan', dest='rendicion', required=True, help='IN_Plan.xlsx o Rendición')
    ap.add_argument('--corte', type=int, required=True, help='último mes cerrado (1-12)')
    ap.add_argument('--anio', type=int, required=True)
    ap.add_argument('--dias-transcurridos', type=float, default=None, help='días hábiles del mes en curso a la fecha de exportación')
    ap.add_argument('--oc', default=None, help='OC abiertas de MP (opcional; sin OC todo el entrante se cuenta en el mes 2)')
    ap.add_argument('--fecha-exportacion', default=None, help='AAAA-MM-DD de la Base de datos (por defecto, --version)')
    ap.add_argument('--version', default='')
    ap.add_argument('--salida', default='presupuesto_por_sku.csv')
    a = ap.parse_args()
    import datetime as _dt
    fx_ = a.fecha_exportacion or a.version
    fexp = _fecha(fx_, _dt.date.today()) if fx_ else _dt.date.today()
    d = calcular(leer_base(a.base), leer_consumo(a.consumo), leer_rendicion(a.rendicion), a.corte, a.anio, a.dias_transcurridos,
                 oc=leer_oc(a.oc) if a.oc else [], fecha_exportacion=fexp)
    t = tabla_larga(d, a.version)
    t.to_csv(a.salida, index=False, encoding='utf-8-sig')
    print(f'{len(d)} SKUs, {len(t)} filas → {a.salida}. Compra total: ${d.rdt.sum():,.0f}')
