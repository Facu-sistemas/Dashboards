import sys, json, os, numpy as np, pandas as pd
from openpyxl import load_workbook
from openpyxl.utils import column_index_from_string as CI
sys.path.insert(0, os.path.dirname(__file__))
from audit_model import model

def read_engine(path):
    COL = json.load(open(os.path.join(os.path.dirname(__file__), 'cols.json')))
    ws = load_workbook(path, data_only=True, read_only=True)['Cálculo SKU']
    rows = list(ws.iter_rows(min_row=3, values_only=True))
    df = pd.DataFrame({k: [r[CI(c) - 1] for r in rows] for k, c in COL.items()})
    return df[df.sku.notna() & (df.sku != '')].reset_index(drop=True)

def compare(path, **kw):
    x = read_engine(path)
    y, meta = model(**kw)
    x = x.set_index('sku'); y = y.set_index('sku')
    issues = []
    miss = set(y.index) ^ set(x.index)
    if miss: issues.append(('sku set mismatch', list(miss)[:10]))
    num = ['costo', 'disp', 'ent', 'c1', 'c2', 'c3', 'c4', 'coefb', 'coef', 'p1', 'p2', 'p3', 'p4', 'p5', 'pv', 'lt', 'ss', 'obs', 'mxs',
           'r1', 'r2', 'r3', 'r4', 'rdt', 'o0u', 'o1u', 'o2u', 'o3u', 'o4u', 'va', 'vi', 'sm', 'ex', 'disc', 'cap', 'wref',
           'rg1', 'rg2', 'rg3', 'rg4', 'ch1', 'ch2', 'ch3', 'ch4', 'bk1', 'bk2', 'bk3', 'bk4', 'fal1', 'fal2', 'fal3', 'fal4',
           'en1', 'en2', 'en3', 'en4', 'q27', 'em27', 'qm', 'idw', 'ltb', 'lm', 'lmb', 'mag', 'e1', 'e2', 'e3', 'e4', 'e5', 'ev', 'esf', 'oca', 'ocp']
    txt = ['cat', 'lin', 'met', 'drv', 'abc', 'tend', 'est', 'ori', 'resp']
    common = [s for s in y.index if s in x.index]
    report = {}
    for c in num:
        a = pd.to_numeric(x.loc[common, c], errors='coerce').fillna(0).astype(float).values
        b = y.loc[common, c].astype(float).fillna(0).values
        bad = np.abs(a - b) > 1e-6 * np.maximum(1, np.abs(b)) + 1e-6
        report[c] = int(bad.sum())
        if bad.any(): issues.append((c, [(common[i], a[i], b[i]) for i in np.where(bad)[0][:5]]))
    for c in txt:
        a = x.loc[common, c].fillna('').astype(str).values; b = y.loc[common, c].fillna('').astype(str).values
        bad = a != b; report[c] = int(bad.sum())
        if bad.any(): issues.append((c, [(common[i], a[i], b[i]) for i in np.where(bad)[0][:5]]))
    tot = dict(libro=float(pd.to_numeric(x.rdt).sum()), python=float(y.rdt.sum()))
    return report, issues, tot, meta, x, y

if __name__ == '__main__':
    import datetime as dt
    from audit_model import leer_oc
    oc = leer_oc(sys.argv[5]) if len(sys.argv) > 5 else []
    rep, iss, tot, meta, x, y = compare(sys.argv[1], UP=sys.argv[2], cutoff=int(sys.argv[3]), dh_manual=float(sys.argv[4]), oc=oc, fexp=dt.date.fromisoformat(os.environ.get('FEXP', '2026-10-02')))
    print('SKUs', len(x), len(y)); print('diferencias por campo:', {k: v for k, v in rep.items() if v} or 'NINGUNA')
    for i in iss: print(i)
    print('totales', tot); print('meta', {k: v for k, v in meta.items() if k != 'calib'})
