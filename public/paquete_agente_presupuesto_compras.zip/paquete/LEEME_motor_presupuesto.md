# Motor del Presupuesto de Compras (Python)

**Archivo:** `presupuesto_compras.py`
**Versión:** 07/10/2026, validada contra `Presupuesto_Compras_MP_v11.xlsx`

## Qué es

El mismo cálculo del libro de Excel (hoja *Cálculo SKU*), escrito en Python para que el aplicativo pueda correrlo sin depender del Excel.

Se verificó contra el libro con los datos del 06/10 (septiembre cerrado, horizonte octubre–enero). La tabla que genera es idéntica a la hoja oculta *Exportar*: 2.504 filas × 22 columnas, sin diferencias. La compra total es de $3.384,2M en los dos.

**Cambios de la v11:** acepta el archivo `IN_Plan.xlsx` (mismo formato que la hoja IN_Plan) en lugar de la Rendición (`--plan` o `--rendicion`, detecta el formato solo). Excepciones nuevas: 29 insumos de líneas discontinuadas de China (bases Pocket de altura 23, Boucle Nova, Cuero Silk/Stik, Dense Hermes, Form/Givenchy) con método *Discontinuado*; todas las Pocket de altura 18, incluida la 85X185X18, se compran en Brasil.

## Requisitos

Python 3.9 o superior, con `pandas`, `numpy` y `openpyxl`.

## Uso rápido

```bash
python presupuesto_compras.py \
  --base IN_Base.xlsx --consumo IN_Consumo.xlsx --plan IN_Plan.xlsx \
  --oc oc_pendientes_mp.xlsx \
  --corte 9 --anio 2026 --dias-transcurridos 4 --fecha-exportacion 2026-10-06 --version 2026-10-06 --salida presupuesto_por_sku.csv
```

- `--corte`: último mes **cerrado** del historial de consumo (9 = septiembre). Se calibra con los 4 meses cerrados hasta ese mes y se proyecta desde el mes siguiente.
- `--oc` (opcional): OC abiertas de MP, con el formato de la exportación de Facu. Se usan para ubicar el entrante por mes de llegada. Sin este archivo, todo el entrante se cuenta en el mes 2.
- `--fecha-exportacion` (opcional): fecha de la Base de datos (AAAA-MM-DD). Si no se pasa, se toma `--version`. Define qué OC están vencidas y cuántos días quedan del mes en curso.
- `--dias-transcurridos` (opcional): días hábiles del mes en curso **a la fecha de la exportación**. Si no se pasa, se toma el valor del plan (fila "Días hábiles transcurridos").

## Uso desde código

```python
import datetime
from presupuesto_compras import leer_base, leer_consumo, leer_rendicion, leer_oc, calcular, tabla_larga
d = calcular(leer_base('IN_Base.xlsx'), leer_consumo('IN_Consumo.xlsx'), leer_rendicion('IN_Rendicion.xlsx'), corte=9, anio=2026, dias_transcurridos=2,
              oc=leer_oc('oc_pendientes_mp.xlsx'), fecha_exportacion=datetime.date(2026, 10, 2))
tabla = tabla_larga(d, version='2026-10-02')   # una fila por SKU y mes
```

`calcular` devuelve una fila por SKU con todas las columnas intermedias. Son las mismas claves que las columnas de *Cálculo SKU*: `p1..p5` consumo proyectado, `rg/ch/bk` compra regular, importación y respaldo por mes, `en1..en4` stock de cierre, `e1..e4` entrante por mes, `o1..o4` órdenes, `o0` faltante antes de poder recibir, `abc`, `ori`, `resp`, etc.

## Salida (`tabla_larga`)

Una fila por SKU y mes, con estas columnas:

- Versión, Mes (AAAA-MM), Mes, SKU
- Categoría, Línea, Proveedor (1° en Odoo), Origen, Respaldo, Clase ABC
- Costo unitario, Llegada (u y $), Regular (u), Importación China (u), Respaldo (u)
- Emitir orden (u y $), Faltante bajo seguridad antes de poder recibir (u), Consumo proyectado (u), Déficit sin respaldo (u), Entrante que llega (u)

## Reglas (diccionario `CONFIG`)

Las reglas que mantiene Compras están en el diccionario `CONFIG` al comienzo del archivo:

- supuestos (hoja Parámetros);
- plan de enero del año siguiente (`plan_enero_siguiente`): la Rendición es anual; si queda vacío se usa diciembre;
- política por origen: lead time en días, stock de seguridad mínimo y ciclo de compra;
- línea por categoría;
- colecciones;
- químicos principales;
- origen de cada proveedor;
- excepciones por SKU.

Hoy esas reglas viven en **dos lugares**: el libro (hoja Parámetros) y este diccionario. Si Compras cambia una regla en el libro, hay que replicarla acá.

Para una versión en línea conviene que las reglas estén en **una sola fuente**, por ejemplo una tabla en la base del aplicativo o en Odoo, y que tanto el motor como el libro las lean de ahí.

## Para vincular con Odoo

Hoy la clave del insumo es el **nombre** del producto. Conviene sumar la **Referencia interna** o el **ID** a la exportación de Base de datos y usarla como clave en lugar del nombre.

Las tres entradas se pueden reemplazar por consultas directas a Odoo, siempre de **solo lectura**:

| Entrada | De dónde sale en Odoo |
|---|---|
| Base de datos | `product.product`, con stock disponible, entrante, costo y proveedores de `product.supplierinfo` |
| Historial de consumo | Movimientos de consumo por mes (`stock.move`) |
| Rendición | Planilla externa, no está en Odoo |
| OC abiertas | `purchase.order.line` con cantidad pendiente y `date_planned` |
